@echo off
REM One-step deploy of the SkillBridge website to GitHub Pages (Windows).
REM Requires: Git for Windows, signed in to GitHub on this computer.
setlocal
set REPO=https://github.com/hellomanavlab-cmyk/SkillBridge.git
set BRANCH=main
set WORK=%TEMP%\skillbridge-deploy-%RANDOM%
set HERE=%~dp0
echo Cloning %REPO% ...
git clone --branch %BRANCH% %REPO% "%WORK%" || goto :fail
cd /d "%WORK%" || goto :fail
git archive --format=zip -o "%HERE%backup-old-repo.zip" HEAD || goto :fail
echo Backup of the old website saved: %HERE%backup-old-repo.zip
powershell -NoProfile -Command "Get-ChildItem -Force | Where-Object { $_.Name -ne '.git' } | Remove-Item -Recurse -Force"
robocopy "%HERE%site" "%WORK%" /E /NFL /NDL /NJH /NJS /NP >nul
git add -A
git diff --cached --quiet && (echo No changes to deploy. & goto :done)
git -c user.name="SkillBridge Deploy" -c user.email="skillbridge.manavlab@gmail.com" commit -m "Website update: policies, leads, premium, explore pages" || goto :fail
git push origin %BRANCH% || goto :fail
echo Pushed. Wait 1-2 minutes, then open https://hellomanavlab-cmyk.github.io/SkillBridge/
:done
cd /d "%TEMP%"
rmdir /s /q "%WORK%" 2>nul
pause
goto :eof
:fail
echo Deploy failed. Check that Git is installed and you are signed in to GitHub.
pause
