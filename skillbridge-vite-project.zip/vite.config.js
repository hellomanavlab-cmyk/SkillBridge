import { defineConfig } from "vite";
import { resolve } from "path";

// Minimal config — no framework plugins, since the site itself is
// plain HTML/CSS/JS. Vite is only here to provide a proper build
// step, multi-page routing, and real environment-variable support
// (import.meta.env).
export default defineConfig({
  // Relative base so the built output works whether it's hosted at
  // a domain root (Netlify, custom domain) OR in a subfolder (GitHub
  // Pages project sites, e.g. username.github.io/repo-name/) —
  // combined with the project-wide relative-path fix, no base path
  // needs to be hardcoded here.
  base: "./",
  build: {
    outDir: "dist",
    rollupOptions: {
      input: {
        page_complaints_policy: resolve(__dirname, "complaints-policy.html"),
        page_cookie_policy: resolve(__dirname, "cookie-policy.html"),
        page_disclaimer: resolve(__dirname, "disclaimer.html"),
        page_expert_network_policy: resolve(__dirname, "expert-network-policy.html"),
        page_opportunity_policy: resolve(__dirname, "opportunity-policy.html"),
        page_payment_policy: resolve(__dirname, "payment-policy.html"),
        page_policies: resolve(__dirname, "policies.html"),
        page_privacy_policy: resolve(__dirname, "privacy-policy.html"),
        page_project_collaboration_terms: resolve(__dirname, "project-collaboration-terms.html"),
        page_refund_cancellation_policy: resolve(__dirname, "refund-cancellation-policy.html"),
        page_service_policy: resolve(__dirname, "service-policy.html"),
        page_terms_of_service: resolve(__dirname, "terms-of-service.html"),
        main: resolve(__dirname, "index.html"),
        login: resolve(__dirname, "login.html"),
        signup: resolve(__dirname, "signup.html"),
        forgotPassword: resolve(__dirname, "forgot-password.html"),
        resetPassword: resolve(__dirname, "reset-password.html"),
        dashboard: resolve(__dirname, "dashboard.html"),
        profile: resolve(__dirname, "profile.html"),
        opportunities: resolve(__dirname, "opportunities.html"),
        opportunity: resolve(__dirname, "opportunity.html"),
        savedOpportunities: resolve(__dirname, "saved-opportunities.html"),
        adminOpportunities: resolve(__dirname, "admin-opportunities.html"),
        campaigns: resolve(__dirname, "campaigns.html"),
        campaignNew: resolve(__dirname, "campaign-new.html"),
        campaignDetail: resolve(__dirname, "campaign-detail.html"),
        outreach: resolve(__dirname, "outreach.html"),
        analytics: resolve(__dirname, "analytics.html"),
        reports: resolve(__dirname, "reports.html"),
        billing: resolve(__dirname, "billing.html"),
        suspended: resolve(__dirname, "suspended.html"),
        admin: resolve(__dirname, "admin.html"),
        adminUsers: resolve(__dirname, "admin-users.html"),
        adminUserDetail: resolve(__dirname, "admin-user-detail.html"),
        adminCampaigns: resolve(__dirname, "admin-campaigns.html"),
        adminOutreach: resolve(__dirname, "admin-outreach.html"),
        adminBilling: resolve(__dirname, "admin-billing.html"),
        adminSecurity: resolve(__dirname, "admin-security.html"),
        adminSettings: resolve(__dirname, "admin-settings.html"),
        adminOffers: resolve(__dirname, "admin-offers.html"),
      },
    },
  },
});
