-- SkillBridge — profiles table, RLS, and auto-provisioning trigger
-- Run this once in Supabase SQL Editor (or via `supabase db push`
-- if you adopt the Supabase CLI later). Safe to re-run: every
-- statement is guarded with IF NOT EXISTS / OR REPLACE / DROP...IF EXISTS.

-- ---------------------------------------------------------------
-- 1. TABLE
-- ---------------------------------------------------------------
create table if not exists public.profiles (
  id                 uuid primary key references auth.users(id) on delete cascade,
  full_name          text,
  email              text not null,
  phone              text,
  country            text,
  city               text,
  main_skill         text,
  services           text,
  portfolio_url      text,
  experience         text,
  target_industries  text,
  target_countries   text,
  preferred_market   text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

comment on table public.profiles is 'One row per authenticated SkillBridge user. id mirrors auth.users.id.';

-- ---------------------------------------------------------------
-- 2. ROW LEVEL SECURITY
-- ---------------------------------------------------------------
alter table public.profiles enable row level security;

-- Table-level grants: RLS decides *which rows*, but Postgres still
-- needs the role to be allowed to attempt the operation at all.
-- Deliberately NOT granting anything to `anon` — logged-out
-- requests should never even attempt to touch this table.
grant usage on schema public to authenticated;
grant select, insert, update on public.profiles to authenticated;

drop policy if exists "Users can view own profile" on public.profiles;
create policy "Users can view own profile"
  on public.profiles for select
  to authenticated
  using (auth.uid() = id);

drop policy if exists "Users can insert own profile" on public.profiles;
create policy "Users can insert own profile"
  on public.profiles for insert
  to authenticated
  with check (auth.uid() = id);

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- No DELETE policy and no policy for `anon` at all: by default,
-- RLS denies any operation that has no matching policy, so profiles
-- cannot be deleted from the client and are never publicly readable.

-- ---------------------------------------------------------------
-- 3. AUTO-CREATE PROFILE ON SIGNUP
-- ---------------------------------------------------------------
-- SECURITY DEFINER is required here: this trigger fires as part of
-- the server-side insert into auth.users during signup, before the
-- new user has an active session — so the normal RLS policies above
-- (which check auth.uid() = id) would otherwise block the insert.
-- Running as the function owner (not the client's role) is what
-- lets this specific, narrow insert succeed. It never touches
-- anything the client controls, and it stores no password.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ---------------------------------------------------------------
-- 4. KEEP updated_at ACCURATE
-- ---------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_profiles_updated_at on public.profiles;
create trigger set_profiles_updated_at
  before update on public.profiles
  for each row execute procedure public.set_updated_at();
