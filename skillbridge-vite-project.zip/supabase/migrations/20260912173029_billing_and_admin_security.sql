-- SkillBridge — Billing foundation + Admin Dashboard security layer
-- Steps 11-12. Run after the previous two migrations.
-- Safe to re-run: guarded with IF NOT EXISTS / OR REPLACE / DROP...IF EXISTS.

-- =================================================================
-- 1. SUBSCRIPTIONS (billing foundation — no payment integration)
-- =================================================================
create table if not exists public.subscriptions (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null unique references auth.users(id) on delete cascade,
  plan           text not null default 'FREE' check (plan in ('FREE','STARTER','GROWTH','CUSTOM')),
  status         text not null default 'ACTIVE' check (status in ('ACTIVE','TRIAL','PAUSED','CANCELLED','EXPIRED')),
  billing_cycle  text,
  started_at     timestamptz not null default now(),
  expires_at     timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

alter table public.subscriptions enable row level security;

-- Only SELECT is granted to authenticated users. Deliberately no
-- INSERT/UPDATE/DELETE grant at all — a user cannot upgrade
-- themselves by any client request, full stop. Provisioning happens
-- only via the SECURITY DEFINER trigger below (on signup); future
-- paid-plan changes belong to a trusted server-side process using
-- the service-role key (which bypasses RLS entirely and isn't
-- subject to this grant), never the browser.
grant select on public.subscriptions to authenticated;

drop policy if exists "Users can view own subscription" on public.subscriptions;
create policy "Users can view own subscription"
  on public.subscriptions for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Admins can view all subscriptions" on public.subscriptions;
create policy "Admins can view all subscriptions"
  on public.subscriptions for select
  to authenticated
  using (public.is_admin());

drop trigger if exists set_subscriptions_updated_at on public.subscriptions;
create trigger set_subscriptions_updated_at
  before update on public.subscriptions
  for each row execute procedure public.set_updated_at();

-- Every new signup gets a FREE/ACTIVE subscription automatically.
create or replace function public.handle_new_user_subscription()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.subscriptions (user_id, plan, status)
  values (new.id, 'FREE', 'ACTIVE')
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_subscription on auth.users;
create trigger on_auth_user_created_subscription
  after insert on auth.users
  for each row execute procedure public.handle_new_user_subscription();

-- Backfill: give a FREE subscription to any existing user who signed
-- up before this migration ran, so "existing users without a
-- subscription safely receive Free state" is true at the DB level
-- too, not just as a client-side fallback.
insert into public.subscriptions (user_id, plan, status)
select u.id, 'FREE', 'ACTIVE'
from auth.users u
left join public.subscriptions s on s.user_id = u.id
where s.id is null;

-- =================================================================
-- 2. ACCOUNT SUSPENSION (admin-only field-level protection)
-- =================================================================
alter table public.profiles
  add column if not exists account_status text not null default 'ACTIVE'
  check (account_status in ('ACTIVE','SUSPENDED'));

-- Admins need to update *other* users' profiles (to suspend/
-- reactivate, or for support). The existing "Users can update own
-- profile" policy only ever matched auth.uid() = id, so it can't be
-- (ab)used for this — we add a distinct, narrowly-gated policy.
drop policy if exists "Admins can update any profile" on public.profiles;
create policy "Admins can update any profile"
  on public.profiles for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "Admins can view any profile" on public.profiles;
create policy "Admins can view any profile"
  on public.profiles for select
  to authenticated
  using (public.is_admin());

-- Belt-and-suspenders: even though normal users' own UPDATE policy
-- was never intended to let them touch account_status, nothing
-- currently stops it at the column level. This trigger silently
-- reverts any change to account_status made by a non-admin, so a
-- user can never un-suspend (or suspend) themselves by crafting a
-- request against their own row.
create or replace function public.protect_account_status()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.account_status is distinct from old.account_status and not public.is_admin() then
    new.account_status = old.account_status;
  end if;
  return new;
end;
$$;

drop trigger if exists protect_account_status_trigger on public.profiles;
create trigger protect_account_status_trigger
  before update on public.profiles
  for each row execute procedure public.protect_account_status();

create index if not exists idx_profiles_account_status on public.profiles (account_status);

-- =================================================================
-- 3. ADMIN AUDIT LOG
-- =================================================================
create table if not exists public.admin_audit_logs (
  id             uuid primary key default gen_random_uuid(),
  admin_user_id  uuid not null references auth.users(id) on delete cascade,
  action         text not null,
  target_type    text,
  target_id      uuid,
  metadata       jsonb,
  created_at     timestamptz not null default now()
);

comment on table public.admin_audit_logs is
  'Never store passwords, tokens, API keys, or other secrets in metadata.';

alter table public.admin_audit_logs enable row level security;
grant select, insert on public.admin_audit_logs to authenticated;

drop policy if exists "Admins can view audit logs" on public.admin_audit_logs;
create policy "Admins can view audit logs"
  on public.admin_audit_logs for select
  to authenticated
  using (public.is_admin());

-- An admin can only ever write a log row attributed to themselves —
-- nobody can forge another admin's id in admin_user_id, and a
-- non-admin can't write here at all.
drop policy if exists "Admins can write own audit entries" on public.admin_audit_logs;
create policy "Admins can write own audit entries"
  on public.admin_audit_logs for insert
  to authenticated
  with check (public.is_admin() and admin_user_id = auth.uid());

create index if not exists idx_audit_admin on public.admin_audit_logs (admin_user_id);
create index if not exists idx_audit_created on public.admin_audit_logs (created_at desc);
create index if not exists idx_audit_target on public.admin_audit_logs (target_type, target_id);

-- =================================================================
-- 4. ADMIN READ ACCESS FOR PLATFORM-WIDE VIEWS
-- =================================================================
-- These are additive SELECT-only policies (existing owner-only
-- policies are untouched) so /admin/campaigns, /admin/outreach, and
-- the admin overview counts can show real platform data. Admins get
-- no write access to another user's campaigns/opportunities/outreach
-- through these policies — only read.
drop policy if exists "Admins can view all campaigns" on public.campaigns;
create policy "Admins can view all campaigns"
  on public.campaigns for select
  to authenticated
  using (public.is_admin());

drop policy if exists "Admins can view all user_opportunities" on public.user_opportunities;
create policy "Admins can view all user_opportunities"
  on public.user_opportunities for select
  to authenticated
  using (public.is_admin());

drop policy if exists "Admins can view all outreach_contacts" on public.outreach_contacts;
create policy "Admins can view all outreach_contacts"
  on public.outreach_contacts for select
  to authenticated
  using (public.is_admin());

drop policy if exists "Admins can view all campaign_opportunities" on public.campaign_opportunities;
create policy "Admins can view all campaign_opportunities"
  on public.campaign_opportunities for select
  to authenticated
  using (public.is_admin());
