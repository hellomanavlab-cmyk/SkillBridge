-- SkillBridge — profile field additions + admin signup notification
-- Run after all four previous migrations.

-- =================================================================
-- 1. A FEW ADDITIONAL PROFILE FIELDS
-- =================================================================
-- Purely additive, nullable/defaulted — nothing existing changes.
-- Note: "plan" already lives on `subscriptions.plan` (kept there
-- deliberately, not duplicated here, since a user's plan can change
-- independently of their profile and RLS already protects it).
alter table public.profiles add column if not exists avatar_url text;
alter table public.profiles add column if not exists company text;
alter table public.profiles add column if not exists lead_credits integer not null default 0;

comment on column public.profiles.lead_credits is
  'Foundation only — not yet wired to any deduction/consumption logic. Do not display this as an enforced limit anywhere until that logic exists.';

-- =================================================================
-- 2. ADMIN SIGNUP NOTIFICATION (pg_net + Vault — no Edge Function,
--    no frontend code, no secret ever touches the browser)
-- =================================================================
-- Requires the pg_net extension. Enable it once via:
--   Dashboard -> Database -> Extensions -> search "pg_net" -> Enable
-- (or: create extension if not exists pg_net; — needs sufficient
-- privileges, the Dashboard toggle is the simpler path).

create or replace function public.notify_admin_new_signup()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  resend_key text;
  full_name  text;
begin
  select decrypted_secret into resend_key
  from vault.decrypted_secrets
  where name = 'resend_api_key';

  -- No key configured yet? Don't touch signup — just skip silently.
  if resend_key is null then
    return new;
  end if;

  full_name := coalesce(new.raw_user_meta_data->>'full_name', '(not provided)');

  perform net.http_post(
    url := 'https://api.resend.com/emails',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || resend_key,
      'Content-Type', 'application/json'
    ),
    body := jsonb_build_object(
      'from', 'SkillBridge <onboarding@resend.dev>',
      'to', jsonb_build_array('hello.manavlab@gmail.com'),
      'subject', 'New SkillBridge User Signup',
      'html',
        '<p>New user registered on SkillBridge.</p>' ||
        '<p><b>Name:</b> ' || full_name || '</p>' ||
        '<p><b>Email:</b> ' || new.email || '</p>' ||
        '<p><b>Signup time:</b> ' || new.created_at || '</p>' ||
        '<p><b>User ID:</b> ' || new.id || '</p>' ||
        '<p><a href="https://YOUR-DOMAIN-HERE/admin-users.html">Open Admin Dashboard</a></p>'
    )
  );

  return new;
exception when others then
  -- A notification failure must NEVER block a real signup.
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_notify_admin on auth.users;
create trigger on_auth_user_created_notify_admin
  after insert on auth.users
  for each row execute procedure public.notify_admin_new_signup();
