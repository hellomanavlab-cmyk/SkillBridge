-- SkillBridge — Offers system. Run after all previous migrations.
create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  price text,
  discount text,
  cta_label text not null default 'Get Started',
  cta_url text,
  start_date date,
  end_date date,
  status text not null default 'DRAFT' check (status in ('DRAFT','ACTIVE','EXPIRED','ARCHIVED')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.offers enable row level security;
grant select on public.offers to anon, authenticated;
grant insert, update, delete on public.offers to authenticated;

drop policy if exists "Anyone can view active offers" on public.offers;
create policy "Anyone can view active offers" on public.offers for select to anon, authenticated
  using (status = 'ACTIVE' and (start_date is null or start_date <= current_date) and (end_date is null or end_date >= current_date));
drop policy if exists "Admins can view all offers" on public.offers;
create policy "Admins can view all offers" on public.offers for select to authenticated using (public.is_admin());
drop policy if exists "Only admins can create offers" on public.offers;
create policy "Only admins can create offers" on public.offers for insert to authenticated with check (public.is_admin());
drop policy if exists "Only admins can update offers" on public.offers;
create policy "Only admins can update offers" on public.offers for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "Only admins can delete offers" on public.offers;
create policy "Only admins can delete offers" on public.offers for delete to authenticated using (public.is_admin());

drop trigger if exists set_offers_updated_at on public.offers;
create trigger set_offers_updated_at before update on public.offers for each row execute procedure public.set_updated_at();
create index if not exists idx_offers_status on public.offers (status);
create index if not exists idx_offers_dates on public.offers (start_date, end_date);
