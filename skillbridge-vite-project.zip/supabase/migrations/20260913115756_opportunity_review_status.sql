-- SkillBridge — Opportunity review workflow (Step 12 §10)
-- Run after the three previous migrations.
--
-- IMPORTANT DISTINCTION:
--   opportunities.status        -> publish/visibility state (ACTIVE/DRAFT/ARCHIVED),
--                                   already governs the RLS select policy.
--   opportunities.review_status -> admin editorial workflow only. Does NOT
--                                   affect what end users can see — that's
--                                   still controlled entirely by `status`.
--   user_opportunities.status   -> each user's own sales pipeline
--                                   (SAVED/CONTACTED/INTERESTED/WON/...).
-- These three are intentionally independent so a review workflow can
-- never be confused with, or accidentally overwrite, a user's pipeline.

alter table public.opportunities
  add column if not exists review_status text not null default 'APPROVED'
  check (review_status in ('PENDING_REVIEW','APPROVED','REJECTED','ARCHIVED'));

comment on column public.opportunities.review_status is
  'Admin editorial review state. Independent of status (visibility) and of any user''s pipeline status.';

create index if not exists idx_opportunities_review_status on public.opportunities (review_status);

-- Writing review_status is already covered by the existing
-- "Only admins can update opportunities" policy (is_admin()) — no
-- new RLS needed, since it's just another column on the same row.
