-- SkillBridge — Opportunities, Campaigns, Outreach foundation, Admin roles
-- Steps 7-9. Run after 20260912122155_create_profiles.sql.
-- Safe to re-run: guarded with IF NOT EXISTS / OR REPLACE / DROP...IF EXISTS.

-- =================================================================
-- 0. ADMIN ROLE MECHANISM
-- =================================================================
-- A minimal, secure role table — NOT a frontend boolean, NOT a
-- hardcoded email. Only the project owner can grant roles, by
-- running SQL in the Supabase dashboard (or a future admin-only
-- server action). Authenticated users may read their OWN role row
-- (so the UI can decide whether to show admin links), but nobody
-- can write to this table from the client — there is deliberately
-- no INSERT/UPDATE/DELETE policy for `authenticated`.
create table if not exists public.user_roles (
  user_id  uuid not null references auth.users(id) on delete cascade,
  role     text not null check (role in ('admin')),
  granted_at timestamptz not null default now(),
  primary key (user_id, role)
);

alter table public.user_roles enable row level security;
grant select on public.user_roles to authenticated;

drop policy if exists "Users can read own roles" on public.user_roles;
create policy "Users can read own roles"
  on public.user_roles for select
  to authenticated
  using (auth.uid() = user_id);

-- Helper used inside other RLS policies below.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = 'admin'
  );
$$;

-- To make yourself an admin, run manually in SQL Editor:
--   insert into public.user_roles (user_id, role)
--   values ('<your-auth-user-id>', 'admin');

-- =================================================================
-- 1. OPPORTUNITIES (global catalog, admin-managed)
-- =================================================================
create table if not exists public.opportunities (
  id                  uuid primary key default gen_random_uuid(),
  title               text not null,
  company_name        text not null,
  company_website     text,
  industry            text,
  country             text,
  city                text,
  description         text,
  potential_need      text,
  why_relevant        text,
  suggested_approach  text,
  source_url          text,
  opportunity_score   integer check (opportunity_score is null or (opportunity_score between 0 and 100)),
  -- Content lifecycle status, admin-controlled. This is NOT the
  -- per-user pipeline status (that lives on user_opportunities).
  status              text not null default 'ACTIVE' check (status in ('DRAFT','ACTIVE','ARCHIVED')),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

comment on column public.opportunities.opportunity_score is
  'Research-based prioritization indicator (0-100). Not a probability of conversion.';

alter table public.opportunities enable row level security;
grant select on public.opportunities to authenticated;
grant insert, update, delete on public.opportunities to authenticated; -- RLS below still gates by is_admin()

drop policy if exists "Authenticated users can read active opportunities" on public.opportunities;
create policy "Authenticated users can read active opportunities"
  on public.opportunities for select
  to authenticated
  using (status = 'ACTIVE' or public.is_admin());

drop policy if exists "Only admins can insert opportunities" on public.opportunities;
create policy "Only admins can insert opportunities"
  on public.opportunities for insert
  to authenticated
  with check (public.is_admin());

drop policy if exists "Only admins can update opportunities" on public.opportunities;
create policy "Only admins can update opportunities"
  on public.opportunities for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "Only admins can delete opportunities" on public.opportunities;
create policy "Only admins can delete opportunities"
  on public.opportunities for delete
  to authenticated
  using (public.is_admin());

drop trigger if exists set_opportunities_updated_at on public.opportunities;
create trigger set_opportunities_updated_at
  before update on public.opportunities
  for each row execute procedure public.set_updated_at();

create index if not exists idx_opportunities_country on public.opportunities (country);
create index if not exists idx_opportunities_industry on public.opportunities (industry);
create index if not exists idx_opportunities_status on public.opportunities (status);
create index if not exists idx_opportunities_created_at on public.opportunities (created_at desc);
create index if not exists idx_opportunities_score on public.opportunities (opportunity_score desc);

-- =================================================================
-- 2. USER_OPPORTUNITIES (per-user saved/pipeline relationship)
-- =================================================================
create table if not exists public.user_opportunities (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references auth.users(id) on delete cascade,
  opportunity_id  uuid not null references public.opportunities(id) on delete cascade,
  status          text not null default 'SAVED' check (status in (
                    'NEW','SAVED','CONTACTED','FOLLOW_UP','REPLIED',
                    'INTERESTED','MEETING','WON','LOST','NOT_INTERESTED'
                  )),
  notes           text,
  saved_at        timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (user_id, opportunity_id)
);

alter table public.user_opportunities enable row level security;
grant select, insert, update, delete on public.user_opportunities to authenticated;

drop policy if exists "Users can view own saved opportunities" on public.user_opportunities;
create policy "Users can view own saved opportunities"
  on public.user_opportunities for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Users can save opportunities for themselves" on public.user_opportunities;
create policy "Users can save opportunities for themselves"
  on public.user_opportunities for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "Users can update own saved opportunities" on public.user_opportunities;
create policy "Users can update own saved opportunities"
  on public.user_opportunities for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can remove own saved opportunities" on public.user_opportunities;
create policy "Users can remove own saved opportunities"
  on public.user_opportunities for delete
  to authenticated
  using (auth.uid() = user_id);

drop trigger if exists set_user_opportunities_updated_at on public.user_opportunities;
create trigger set_user_opportunities_updated_at
  before update on public.user_opportunities
  for each row execute procedure public.set_updated_at();

create index if not exists idx_user_opps_user on public.user_opportunities (user_id);
create index if not exists idx_user_opps_opportunity on public.user_opportunities (opportunity_id);
create index if not exists idx_user_opps_status on public.user_opportunities (status);

-- =================================================================
-- 3. CAMPAIGNS
-- =================================================================
create table if not exists public.campaigns (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users(id) on delete cascade,
  name         text not null,
  description  text,
  channel      text not null default 'EMAIL' check (channel in ('EMAIL','LINKEDIN','WHATSAPP','MULTI_CHANNEL')),
  status       text not null default 'DRAFT' check (status in ('DRAFT','READY','ACTIVE','PAUSED','COMPLETED','ARCHIVED')),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

alter table public.campaigns enable row level security;
grant select, insert, update, delete on public.campaigns to authenticated;

drop policy if exists "Users can view own campaigns" on public.campaigns;
create policy "Users can view own campaigns"
  on public.campaigns for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Users can create own campaigns" on public.campaigns;
create policy "Users can create own campaigns"
  on public.campaigns for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "Users can update own campaigns" on public.campaigns;
create policy "Users can update own campaigns"
  on public.campaigns for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete own campaigns" on public.campaigns;
create policy "Users can delete own campaigns"
  on public.campaigns for delete
  to authenticated
  using (auth.uid() = user_id);

drop trigger if exists set_campaigns_updated_at on public.campaigns;
create trigger set_campaigns_updated_at
  before update on public.campaigns
  for each row execute procedure public.set_updated_at();

create index if not exists idx_campaigns_user on public.campaigns (user_id);
create index if not exists idx_campaigns_status on public.campaigns (status);

-- =================================================================
-- 4. CAMPAIGN_OPPORTUNITIES (join table)
-- =================================================================
create table if not exists public.campaign_opportunities (
  id              uuid primary key default gen_random_uuid(),
  campaign_id     uuid not null references public.campaigns(id) on delete cascade,
  opportunity_id  uuid not null references public.opportunities(id) on delete cascade,
  created_at      timestamptz not null default now(),
  unique (campaign_id, opportunity_id)
);

alter table public.campaign_opportunities enable row level security;
grant select, insert, delete on public.campaign_opportunities to authenticated;

-- Ownership is proven via the parent campaign, never via a
-- client-supplied user_id (there isn't one on this table).
drop policy if exists "Users can view opportunities in own campaigns" on public.campaign_opportunities;
create policy "Users can view opportunities in own campaigns"
  on public.campaign_opportunities for select
  to authenticated
  using (exists (
    select 1 from public.campaigns c
    where c.id = campaign_opportunities.campaign_id and c.user_id = auth.uid()
  ));

drop policy if exists "Users can add opportunities to own campaigns" on public.campaign_opportunities;
create policy "Users can add opportunities to own campaigns"
  on public.campaign_opportunities for insert
  to authenticated
  with check (
    exists (select 1 from public.campaigns c where c.id = campaign_id and c.user_id = auth.uid())
    and exists (select 1 from public.opportunities o where o.id = opportunity_id and o.status = 'ACTIVE')
  );

drop policy if exists "Users can remove opportunities from own campaigns" on public.campaign_opportunities;
create policy "Users can remove opportunities from own campaigns"
  on public.campaign_opportunities for delete
  to authenticated
  using (exists (
    select 1 from public.campaigns c
    where c.id = campaign_opportunities.campaign_id and c.user_id = auth.uid()
  ));

create index if not exists idx_campaign_opps_campaign on public.campaign_opportunities (campaign_id);
create index if not exists idx_campaign_opps_opportunity on public.campaign_opportunities (opportunity_id);

-- =================================================================
-- 5. OUTREACH_CONTACTS (foundation only — no sending)
-- =================================================================
create table if not exists public.outreach_contacts (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null references auth.users(id) on delete cascade,
  campaign_id         uuid not null references public.campaigns(id) on delete cascade,
  opportunity_id      uuid not null references public.opportunities(id) on delete cascade,
  status              text not null default 'NOT_READY' check (status in (
                        'NOT_READY','READY','QUEUED','SENT','FOLLOW_UP_DUE','REPLIED',
                        'INTERESTED','NOT_INTERESTED','MEETING_REQUEST','UNSUBSCRIBED',
                        'BOUNCED','STOPPED'
                      )),
  email               text,
  contact_name        text,
  company_name        text,
  last_contacted_at   timestamptz,
  next_follow_up_at   timestamptz,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique (campaign_id, opportunity_id)
);

alter table public.outreach_contacts enable row level security;
grant select, insert, update, delete on public.outreach_contacts to authenticated;

drop policy if exists "Users can view own outreach contacts" on public.outreach_contacts;
create policy "Users can view own outreach contacts"
  on public.outreach_contacts for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Users can create own outreach contacts" on public.outreach_contacts;
create policy "Users can create own outreach contacts"
  on public.outreach_contacts for insert
  to authenticated
  with check (
    auth.uid() = user_id
    and exists (select 1 from public.campaigns c where c.id = campaign_id and c.user_id = auth.uid())
  );

drop policy if exists "Users can update own outreach contacts" on public.outreach_contacts;
create policy "Users can update own outreach contacts"
  on public.outreach_contacts for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete own outreach contacts" on public.outreach_contacts;
create policy "Users can delete own outreach contacts"
  on public.outreach_contacts for delete
  to authenticated
  using (auth.uid() = user_id);

drop trigger if exists set_outreach_contacts_updated_at on public.outreach_contacts;
create trigger set_outreach_contacts_updated_at
  before update on public.outreach_contacts
  for each row execute procedure public.set_updated_at();

create index if not exists idx_outreach_user on public.outreach_contacts (user_id);
create index if not exists idx_outreach_campaign on public.outreach_contacts (campaign_id);
create index if not exists idx_outreach_status on public.outreach_contacts (status);
