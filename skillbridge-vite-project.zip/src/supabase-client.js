// SkillBridge — Supabase client
// -----------------------------------------------------------------
// This reads the project URL and PUBLISHABLE (anon) key from Vite's
// environment variables at build time. Neither value is hardcoded
// here — they come from your .env file locally, and from your
// hosting provider's environment-variable settings in production.
//
// SECURITY NOTE:
// - Only ever put the PUBLISHABLE / anon key in VITE_ variables.
//   It is safe to ship to the browser by design — Supabase's Row
//   Level Security (RLS) policies are what actually protect your
//   data, not the secrecy of this key.
// - The SECRET / service-role key must NEVER be used here, put in a
//   VITE_ variable, or referenced anywhere in frontend code. It
//   belongs only in a server-side environment (e.g. a Supabase Edge
//   Function or your own backend), never in code that ships to a
//   browser.
// -----------------------------------------------------------------

import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabasePublishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

if (!supabaseUrl || !supabasePublishableKey) {
  console.error(
    "[SkillBridge] Missing Supabase env vars. Check that VITE_SUPABASE_URL and " +
    "VITE_SUPABASE_PUBLISHABLE_KEY are set in your .env file (local) or your " +
    "hosting provider's environment variable settings (production)."
  );
}

export const supabase = createClient(supabaseUrl, supabasePublishableKey);

// Exposed for quick manual testing in the browser console, e.g.:
//   window.supabaseClient.from('table').select('*')
// Remove this if you'd rather keep it strictly module-scoped.
window.supabaseClient = supabase;
