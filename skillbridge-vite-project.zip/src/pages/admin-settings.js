import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");

await mountAdminShell({ activeKey: "settings", pageTitle: "Platform Settings" });

const KEY = "skillbridge_admin_settings_placeholder";

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(KEY)) || {};
    if (saved.platformName) document.getElementById("sPlatformName").value = saved.platformName;
    if (saved.maintenance) document.getElementById("sMaintenance").checked = saved.maintenance;
    if (saved.defaultOppStatus) document.getElementById("sDefaultOppStatus").value = saved.defaultOppStatus;
  } catch { /* ignore */ }
}

document.getElementById("saveSettingsBtn").addEventListener("click", () => {
  localStorage.setItem(KEY, JSON.stringify({
    platformName: document.getElementById("sPlatformName").value,
    maintenance: document.getElementById("sMaintenance").checked,
    defaultOppStatus: document.getElementById("sDefaultOppStatus").value,
  }));
  const alertBox = document.getElementById("settingsAlert");
  alertBox.textContent = "Saved locally on this device.";
  alertBox.className = "alert show alert-success";
});

load();
