import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import { listCampaigns, deleteCampaign, PAGE_SIZE } from "../data/campaigns.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();

await mountAppShell({
  activeKey: "campaigns",
  pageTitle: "Campaigns",
  user: session.user,
  displayName: profile?.full_name?.trim() || session.user.email,
});

const resultsEl = document.getElementById("campaignResults");
const paginationEl = document.getElementById("pagination");
const searchInput = document.getElementById("cSearch");
const statusSelect = document.getElementById("cStatus");
const channelSelect = document.getElementById("cChannel");
let page = 1;
let searchDebounce;

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

searchInput.addEventListener("input", () => { clearTimeout(searchDebounce); searchDebounce = setTimeout(() => { page = 1; load(); }, 350); });
statusSelect.addEventListener("change", () => { page = 1; load(); });
channelSelect.addEventListener("change", () => { page = 1; load(); });

async function load() {
  resultsEl.innerHTML = `<div class="empty-state"><p>Loading…</p></div>`;
  const { data, count, error } = await listCampaigns({
    search: searchInput.value, status: statusSelect.value, channel: channelSelect.value, page,
  });

  if (error) {
    resultsEl.innerHTML = `<div class="alert show alert-error">Couldn't load campaigns.</div>`;
    return;
  }
  if (!data.length) {
    resultsEl.innerHTML = `
      <div class="empty-state">
        <div class="e-ico"><svg width="22" height="22" viewBox="0 0 20 20" fill="none"><path d="M3 8.5V11.5L6 12.5V15.5C6 16.3 6.7 17 7.5 17C8.3 17 9 16.3 9 15.5V13L15 15V5L9 7L3 8.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg></div>
        <h4>No campaigns yet.</h4>
        <p><a href="campaign-new.html" style="color:var(--teal); font-weight:600">Create your first campaign →</a></p>
      </div>`;
    paginationEl.style.display = "none";
    return;
  }

  resultsEl.innerHTML = `
    <table class="data-table">
      <thead><tr><th>Name</th><th>Channel</th><th>Opportunities</th><th>Status</th><th>Created</th><th>Updated</th><th></th></tr></thead>
      <tbody>
        ${data.map(rowHtml).join("")}
      </tbody>
    </table>
    <div class="mobile-cards">
      ${data.map((c) => `
        <div class="card">
          <div class="card-row"><b>${escapeHtml(c.name)}</b><span class="badge badge-navy">${c.status}</span></div>
          <div style="font-size:13px; color:var(--ink-soft); margin-top:6px">${escapeHtml(c.channel)} · ${c.campaign_opportunities?.[0]?.count ?? 0} opportunities</div>
          <div class="actions" style="margin-top:10px">
            <a href="campaign-detail.html?id=${c.id}" class="btn btn-outline btn-sm">View</a>
            <button class="btn btn-danger btn-sm delete-btn" data-id="${c.id}">Delete</button>
          </div>
        </div>
      `).join("")}
    </div>
  `;

  function rowHtml(c) {
    return `
      <tr>
        <td>${escapeHtml(c.name)}</td>
        <td>${escapeHtml(c.channel)}</td>
        <td>${c.campaign_opportunities?.[0]?.count ?? 0}</td>
        <td><span class="badge badge-navy">${c.status}</span></td>
        <td>${fmtDate(c.created_at)}</td>
        <td>${fmtDate(c.updated_at)}</td>
        <td class="row-actions">
          <a href="campaign-detail.html?id=${c.id}" class="btn btn-outline btn-sm">View</a>
          <button class="btn btn-danger btn-sm delete-btn" data-id="${c.id}">Delete</button>
        </td>
      </tr>`;
  }

  resultsEl.querySelectorAll(".delete-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Delete this campaign? This also removes its opportunity assignments.")) return;
      await deleteCampaign(btn.dataset.id);
      load();
    });
  });

  renderPagination(count);
}

function renderPagination(count) {
  const totalPages = Math.max(Math.ceil(count / PAGE_SIZE), 1);
  if (totalPages <= 1) { paginationEl.style.display = "none"; return; }
  paginationEl.style.display = "flex";
  paginationEl.innerHTML = "";
  for (let p = 1; p <= totalPages; p++) {
    const btn = document.createElement("button");
    btn.textContent = p;
    if (p === page) btn.classList.add("active");
    btn.addEventListener("click", () => { page = p; load(); });
    paginationEl.appendChild(btn);
  }
}

load();
