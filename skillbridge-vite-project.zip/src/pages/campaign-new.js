import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import { listOpportunities } from "../data/opportunities.js";
import { createCampaign, updateCampaign } from "../data/campaigns.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();

await mountAppShell({
  activeKey: "campaigns",
  pageTitle: "Create Campaign",
  user: session.user,
  displayName: profile?.full_name?.trim() || session.user.email,
});

const form = document.getElementById("campaignForm");
const pickerEl = document.getElementById("oppPicker");
const searchInput = document.getElementById("oppSearch");
const selectedCountEl = document.getElementById("selectedCount");
const alertBox = document.getElementById("formAlert");

const selected = new Set();
let searchDebounce;

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function updateCount() {
  selectedCountEl.textContent = `(${selected.size} selected)`;
}

async function loadPicker() {
  pickerEl.innerHTML = `<p style="font-size:13px; color:var(--ink-soft)">Loading opportunities…</p>`;
  const { data, error } = await listOpportunities({ search: searchInput.value, sort: "newest", page: 1 });

  if (error || !data.length) {
    pickerEl.innerHTML = `<p style="font-size:13px; color:var(--ink-soft)">No opportunities available yet. <a href="opportunities.html" style="color:var(--teal)">Explore opportunities →</a></p>`;
    return;
  }

  pickerEl.innerHTML = data.map((o) => `
    <label class="select-opp-row">
      <input type="checkbox" value="${o.id}" ${selected.has(o.id) ? "checked" : ""}>
      <span class="meta"><b>${escapeHtml(o.company_name)}</b> — ${escapeHtml(o.industry || "—")} · ${escapeHtml(o.city || o.country || "—")} · Score ${o.opportunity_score ?? "—"}</span>
    </label>
  `).join("");

  pickerEl.querySelectorAll('input[type="checkbox"]').forEach((box) => {
    box.addEventListener("change", () => {
      if (box.checked) selected.add(box.value); else selected.delete(box.value);
      updateCount();
    });
  });
}

searchInput.addEventListener("input", () => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(loadPicker, 350);
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const submitter = e.submitter;
  const targetStatus = submitter?.dataset.status || "DRAFT";

  const name = document.getElementById("cName").value.trim();
  if (!name) {
    alertBox.textContent = "Campaign name is required.";
    alertBox.className = "alert show alert-error";
    return;
  }

  const description = document.getElementById("cDescription").value;
  const channel = document.getElementById("cChannel").value;

  form.querySelectorAll("button").forEach((b) => b.disabled = true);

  const { data: campaign, error } = await createCampaign({
    name, description, channel, opportunityIds: [...selected],
  });

  if (error) {
    alertBox.textContent = "Couldn't create the campaign. Please try again.";
    alertBox.className = "alert show alert-error";
    form.querySelectorAll("button").forEach((b) => b.disabled = false);
    return;
  }

  // Draft stays DRAFT (the default); "Create Campaign" moves it to READY
  // only if it actually has opportunities attached — matches the rule
  // that a campaign can't be activated with zero opportunities.
  if (targetStatus === "READY" && selected.size > 0) {
    await updateCampaign(campaign.id, { status: "READY" });
  }

  window.location.href = `campaign-detail.html?id=${campaign.id}`;
});

updateCount();
loadPicker();
