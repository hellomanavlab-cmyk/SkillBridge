import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import { getMySubscription, getUsageCounts } from "../data/billing.js";
import { PLANS, PLAN_ORDER } from "../plans.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();

await mountAppShell({
  activeKey: "billing",
  pageTitle: "Billing & Plans",
  user: session.user,
  displayName: profile?.full_name?.trim() || session.user.email,
});

function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function load() {
  const { data: sub } = await getMySubscription();
  const plan = PLANS[sub?.plan] || PLANS.FREE;

  document.getElementById("currentPlanName").textContent = `${plan.name} Plan`;
  const statusBadge = document.getElementById("currentPlanStatus");
  statusBadge.textContent = sub?.status || "ACTIVE";
  statusBadge.className = `badge ${sub?.status === "ACTIVE" ? "badge-teal" : "badge-gray"}`;

  document.getElementById("planDates").innerHTML = `
    Started ${fmtDate(sub?.started_at)} ${sub?.expires_at ? `· Expires ${fmtDate(sub.expires_at)}` : ""}
  `;
  document.getElementById("currentPlanFeatures").innerHTML = `
    <div style="display:flex; flex-wrap:wrap; gap:8px">
      ${plan.features.map((f) => `<span class="badge badge-gray">${escapeHtml(f)}</span>`).join("")}
    </div>`;

  const cardsEl = document.getElementById("planCards");
  cardsEl.innerHTML = PLAN_ORDER.map((key) => {
    const p = PLANS[key];
    const isCurrent = sub?.plan === key || (!sub?.plan && key === "FREE");
    return `
      <div class="qa-card ${isCurrent ? "" : "disabled"}" style="cursor:default">
        <div class="qa-title">${p.name}</div>
        <div style="font-family:'Manrope'; font-weight:800; font-size:20px; color:var(--navy)">${p.price}</div>
        <div style="font-size:12px; color:var(--ink-soft)">${escapeHtml(p.tagline)}</div>
        ${isCurrent
          ? `<span class="badge badge-teal" style="align-self:flex-start">Current Plan</span>`
          : `<button class="btn btn-outline btn-sm upgrade-btn" data-plan="${p.name}">Upgrade</button>`}
      </div>`;
  }).join("");

  cardsEl.querySelectorAll(".upgrade-btn").forEach((btn) => {
    btn.addEventListener("click", () => alert("Paid plans are coming soon."));
  });

  const usage = await getUsageCounts();
  document.getElementById("usageSaved").textContent = usage.opportunitiesSaved;
  document.getElementById("usageCampaigns").textContent = usage.campaigns;
  document.getElementById("usageOutreach").textContent = usage.outreachContacts;

  document.getElementById("billingHistory").innerHTML = `<div class="empty-state" style="padding:20px 0"><p>No billing history yet.</p></div>`;
  document.getElementById("invoicesSection").innerHTML = `<div class="empty-state" style="padding:20px 0"><p>No invoices yet.</p></div>`;
}

load();
