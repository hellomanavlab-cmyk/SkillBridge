import { updatePassword, passwordIssue, friendlyAuthError } from "../auth.js";
import { supabase } from "../supabase-client.js";

const form = document.getElementById("resetForm");
const btn = document.getElementById("resetBtn");
const alertBox = document.getElementById("resetAlert");
const formWrap = document.getElementById("resetFormWrap");
const invalidWrap = document.getElementById("resetInvalid");

function showAlert(type, message) {
  alertBox.textContent = message;
  alertBox.className = `alert show alert-${type}`;
}
function showFieldError(id, message) {
  const input = document.getElementById(id);
  const err = document.getElementById(id + "Err");
  input.classList.add("error");
  if (err) { err.textContent = message; err.classList.add("show"); }
}
function clearFieldErrors() {
  form.querySelectorAll("input").forEach((el) => el.classList.remove("error"));
  form.querySelectorAll(".field-err").forEach((el) => el.classList.remove("show"));
}
function setLoading(isLoading) {
  btn.disabled = isLoading;
  btn.classList.toggle("loading", isLoading);
  btn.querySelector(".btn-text").textContent = isLoading ? "Updating…" : "Update Password";
}

// Supabase's password-recovery link logs the browser into a temporary
// recovery session automatically (via the URL fragment). If that never
// happens — expired/reused link — there's no valid session to update.
let hasRecoverySession = false;
supabase.auth.onAuthStateChange((event, session) => {
  if (event === "PASSWORD_RECOVERY" || (event === "SIGNED_IN" && session)) {
    hasRecoverySession = true;
    formWrap.style.display = "";
    invalidWrap.style.display = "none";
  }
});

setTimeout(async () => {
  if (hasRecoverySession) return;
  const { data } = await supabase.auth.getSession();
  if (data.session) {
    hasRecoverySession = true;
    formWrap.style.display = "";
    invalidWrap.style.display = "none";
  } else {
    formWrap.style.display = "none";
    invalidWrap.style.display = "";
  }
}, 1200);

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  alertBox.className = "alert";
  clearFieldErrors();

  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;

  let hasError = false;
  const pwIssue = password ? passwordIssue(password) : "Please enter a new password.";
  if (pwIssue) { showFieldError("password", pwIssue); hasError = true; }
  if (password !== confirmPassword) { showFieldError("confirmPassword", "Passwords do not match."); hasError = true; }
  if (hasError) return;

  setLoading(true);
  const { error } = await updatePassword(password);
  setLoading(false);

  if (error) {
    showAlert("error", friendlyAuthError(error));
    return;
  }
  showAlert("success", "Password updated. Redirecting you to login…");
  setTimeout(() => window.location.replace("/login.html"), 1800);
});
