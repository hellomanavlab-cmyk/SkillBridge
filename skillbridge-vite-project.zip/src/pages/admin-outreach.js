import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";
import { supabase } from "../supabase-client.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");

await mountAdminShell({ activeKey: "outreach", pageTitle: "Outreach" });

const STATUSES = ["READY", "QUEUED", "SENT", "FOLLOW_UP_DUE", "REPLIED", "INTERESTED", "NOT_INTERESTED", "BOUNCED", "UNSUBSCRIBED", "STOPPED"];

async function load() {
  const { data: contacts } = await supabase.from("outreach_contacts").select("status");
  const statGrid = document.getElementById("outreachStats");

  const countOf = (s) => (contacts || []).filter((c) => c.status === s).length;
  statGrid.innerHTML = STATUSES.map((s) => `
    <div class="stat-card"><div class="num">${countOf(s)}</div><div class="lbl">${s.replace(/_/g, " ")}</div></div>
  `).join("");

  const sentCount = countOf("SENT") + countOf("FOLLOW_UP_DUE") + countOf("REPLIED") + countOf("INTERESTED") + countOf("BOUNCED");
  const noteEl = document.getElementById("noActivityNote");
  if (!contacts?.length || sentCount === 0) {
    noteEl.innerHTML = `<div class="alert show alert-info">No automated outreach activity yet. Message sending is not implemented — these numbers reflect preparation status only.</div>`;
  }
}

load();
