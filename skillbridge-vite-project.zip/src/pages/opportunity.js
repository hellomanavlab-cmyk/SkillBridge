import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import { getOpportunity, getMyRelationship, saveOpportunity, removeSavedOpportunity, updateRelationship } from "../data/opportunities.js";
import { listCampaigns, addOpportunitiesToCampaign, createCampaign } from "../data/campaigns.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();

await mountAppShell({
  activeKey: "opportunities",
  pageTitle: "Opportunity Details",
  user: session.user,
  displayName: profile?.full_name?.trim() || session.user.email,
});

const wrap = document.getElementById("oppDetailWrap");
const params = new URLSearchParams(window.location.search);
const id = params.get("id");

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

const STATUS_OPTIONS = ["NEW", "SAVED", "CONTACTED", "FOLLOW_UP", "REPLIED", "INTERESTED", "MEETING", "WON", "LOST", "NOT_INTERESTED"];

async function render() {
  if (!id) {
    wrap.innerHTML = `<div class="empty-state"><h4>Missing opportunity ID.</h4><p>This link doesn't point to a valid opportunity.</p></div>`;
    return;
  }

  const { data: opp, error } = await getOpportunity(id);
  if (error || !opp) {
    wrap.innerHTML = `<div class="empty-state"><h4>This opportunity is no longer available.</h4><p>It may have been removed or archived.</p></div>`;
    return;
  }

  const { data: relation } = await getMyRelationship(id);
  const isSaved = !!relation;
  const currentStatus = relation?.status || "NEW";

  wrap.innerHTML = `
    <div style="display:grid; grid-template-columns:2fr 1fr; gap:20px" id="detailGrid">
      <div>
        <div class="card">
          <div class="card-row" style="align-items:flex-start">
            <div>
              <h2 style="font-size:22px">${escapeHtml(opp.company_name)}</h2>
              <div style="font-size:13.5px; color:var(--ink-soft); margin-top:6px">
                ${escapeHtml(opp.industry || "—")} · ${escapeHtml([opp.city, opp.country].filter(Boolean).join(", ") || "—")}
              </div>
              ${opp.company_website ? `<a href="${escapeHtml(opp.company_website)}" target="_blank" rel="noopener" style="font-size:13px; color:var(--teal); font-weight:600; margin-top:6px; display:inline-block">${escapeHtml(opp.company_website)} ↗</a>` : ""}
            </div>
            <span class="badge badge-navy">${escapeHtml(currentStatus)}</span>
          </div>
        </div>

        <div class="card" style="margin-top:16px">
          <h3 style="font-size:15px">Opportunity Intelligence</h3>
          <div style="margin-top:14px; display:flex; flex-direction:column; gap:14px">
            <div><div class="eyebrow">Potential Need</div><p style="margin-top:4px; font-size:14px">${escapeHtml(opp.potential_need || "Not specified.")}</p></div>
            <div><div class="eyebrow">Why This May Be Relevant</div><p style="margin-top:4px; font-size:14px">${escapeHtml(opp.why_relevant || "Not specified.")}</p></div>
            <div><div class="eyebrow">Suggested Approach</div><p style="margin-top:4px; font-size:14px">${escapeHtml(opp.suggested_approach || "Not specified.")}</p></div>
          </div>
        </div>

        ${opp.source_url ? `
        <div class="card" style="margin-top:16px">
          <h3 style="font-size:15px">Source</h3>
          <a href="${escapeHtml(opp.source_url)}" target="_blank" rel="noopener" style="font-size:13.5px; color:var(--teal); font-weight:600">${escapeHtml(opp.source_url)} ↗</a>
        </div>` : ""}
      </div>

      <div>
        <div class="card">
          <h3 style="font-size:15px">Opportunity Score</h3>
          <div style="font-family:'Manrope'; font-weight:800; font-size:38px; color:var(--navy); margin-top:10px">${opp.opportunity_score ?? "—"}<span style="font-size:15px; color:var(--ink-soft); font-weight:600">/100</span></div>
          <p style="font-size:12.5px; color:var(--ink-soft); margin-top:10px; line-height:1.6">This is a research-based prioritization indicator, not a guarantee of conversion or project availability.</p>
        </div>

        <div class="card" style="margin-top:16px">
          <h3 style="font-size:15px">Actions</h3>
          <button class="btn ${isSaved ? "btn-outline" : "btn-primary"} btn-sm" id="saveBtn" style="width:100%; margin-top:12px">${isSaved ? "Saved ✓ — Remove" : "Save Opportunity"}</button>
          <button class="btn btn-outline btn-sm" id="contactedBtn" style="width:100%; margin-top:10px">Mark Contacted</button>

          <div class="field">
            <label for="statusSelect">Change status</label>
            <select id="statusSelect" ${isSaved ? "" : "disabled"}>
              ${STATUS_OPTIONS.map((s) => `<option value="${s}" ${s === currentStatus ? "selected" : ""}>${s}</option>`).join("")}
            </select>
          </div>

          <div class="field">
            <label for="notesField">Add note</label>
            <textarea id="notesField" placeholder="Private note — only you can see this" ${isSaved ? "" : "disabled"}>${escapeHtml(relation?.notes || "")}</textarea>
          </div>
          <button class="btn btn-primary btn-sm" id="saveNoteBtn" style="width:100%; margin-top:10px" ${isSaved ? "" : "disabled"}>Save Note</button>

          <div class="alert" id="actionAlert"></div>
        </div>

        <div class="card" style="margin-top:16px">
          <h3 style="font-size:15px">Add to Campaign</h3>
          <div id="campaignAddWrap" style="margin-top:10px"></div>
        </div>
      </div>
    </div>
  `;

  wireActions(opp, isSaved);
  await renderCampaignPicker(opp);
}

function wireActions(opp, initiallySaved) {
  let isSaved = initiallySaved;
  const saveBtn = document.getElementById("saveBtn");
  const statusSelect = document.getElementById("statusSelect");
  const notesField = document.getElementById("notesField");
  const saveNoteBtn = document.getElementById("saveNoteBtn");
  const contactedBtn = document.getElementById("contactedBtn");
  const alertBox = document.getElementById("actionAlert");

  function showAlert(type, msg) { alertBox.textContent = msg; alertBox.className = `alert show alert-${type}`; }

  function enableRelationControls() {
    statusSelect.disabled = false;
    notesField.disabled = false;
    saveNoteBtn.disabled = false;
  }

  saveBtn.addEventListener("click", async () => {
    saveBtn.disabled = true;
    if (isSaved) {
      await removeSavedOpportunity(opp.id);
      isSaved = false;
      saveBtn.textContent = "Save Opportunity";
      saveBtn.classList.remove("btn-outline"); saveBtn.classList.add("btn-primary");
      statusSelect.disabled = true; notesField.disabled = true; saveNoteBtn.disabled = true;
    } else {
      await saveOpportunity(opp.id);
      isSaved = true;
      saveBtn.textContent = "Saved ✓ — Remove";
      saveBtn.classList.remove("btn-primary"); saveBtn.classList.add("btn-outline");
      enableRelationControls();
    }
    saveBtn.disabled = false;
  });

  contactedBtn.addEventListener("click", async () => {
    if (!isSaved) { await saveOpportunity(opp.id); isSaved = true; enableRelationControls(); saveBtn.textContent = "Saved ✓ — Remove"; }
    contactedBtn.disabled = true;
    const { error } = await updateRelationship(opp.id, { status: "CONTACTED" });
    contactedBtn.disabled = false;
    if (error) { showAlert("error", "Couldn't update status."); return; }
    statusSelect.value = "CONTACTED";
    showAlert("success", "Marked as contacted.");
  });

  statusSelect.addEventListener("change", async () => {
    const { error } = await updateRelationship(opp.id, { status: statusSelect.value });
    showAlert(error ? "error" : "success", error ? "Couldn't update status." : "Status updated.");
  });

  saveNoteBtn.addEventListener("click", async () => {
    saveNoteBtn.disabled = true;
    const { error } = await updateRelationship(opp.id, { notes: notesField.value });
    saveNoteBtn.disabled = false;
    showAlert(error ? "error" : "success", error ? "Couldn't save note." : "Note saved.");
  });
}

async function renderCampaignPicker(opp) {
  const pickerWrap = document.getElementById("campaignAddWrap");
  const { data: campaigns } = await listCampaigns({ page: 1 });
  const usable = campaigns.filter((c) => c.status !== "ARCHIVED" && c.status !== "COMPLETED");

  pickerWrap.innerHTML = `
    ${usable.length ? `
      <select id="campaignSelect">
        ${usable.map((c) => `<option value="${c.id}">${escapeHtml(c.name)} (${c.status})</option>`).join("")}
      </select>
      <button class="btn btn-outline btn-sm" id="addToCampaignBtn" style="width:100%; margin-top:10px">Add to Selected Campaign</button>
    ` : `<p style="font-size:13px; color:var(--ink-soft)">You don't have any open campaigns yet.</p>`}
    <button class="btn btn-primary btn-sm" id="newCampaignBtn" style="width:100%; margin-top:10px">+ Create New Campaign With This</button>
    <div class="alert" id="campaignAlert"></div>
  `;

  const campaignAlert = document.getElementById("campaignAlert");
  const showAlert = (type, msg) => { campaignAlert.textContent = msg; campaignAlert.className = `alert show alert-${type}`; };

  document.getElementById("addToCampaignBtn")?.addEventListener("click", async () => {
    const campaignId = document.getElementById("campaignSelect").value;
    const { error } = await addOpportunitiesToCampaign(campaignId, [opp.id]);
    showAlert(error ? "error" : "success", error ? "Couldn't add — it may already be in that campaign." : "Added to campaign.");
  });

  document.getElementById("newCampaignBtn").addEventListener("click", async () => {
    const name = prompt("Name your new campaign:", `${opp.company_name} outreach`);
    if (!name) return;
    const { error } = await createCampaign({ name, description: "", channel: "EMAIL", opportunityIds: [opp.id] });
    showAlert(error ? "error" : "success", error ? "Couldn't create campaign." : "Draft campaign created with this opportunity.");
  });
}

render();
