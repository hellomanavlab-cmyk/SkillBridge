import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import { listOpportunities, saveOpportunity, removeSavedOpportunity, getFilterOptions, PAGE_SIZE } from "../data/opportunities.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();

await mountAppShell({
  activeKey: "opportunities",
  pageTitle: "Opportunities",
  user: session.user,
  displayName: profile?.full_name?.trim() || session.user.email,
});

const resultsEl = document.getElementById("oppResults");
const paginationEl = document.getElementById("pagination");
const filters = {
  search: document.getElementById("fSearch"),
  industry: document.getElementById("fIndustry"),
  country: document.getElementById("fCountry"),
  city: document.getElementById("fCity"),
  score: document.getElementById("fScore"),
  sort: document.getElementById("fSort"),
};

let state = { page: 1 };
let searchDebounce;

filters.search.addEventListener("input", () => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(() => { state.page = 1; load(); }, 350);
});
["industry", "country", "city", "score", "sort"].forEach((key) => {
  filters[key].addEventListener("change", () => { state.page = 1; load(); });
});

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function renderEmpty() {
  resultsEl.innerHTML = `
    <div class="empty-state">
      <div class="e-ico"><svg width="22" height="22" viewBox="0 0 20 20" fill="none"><circle cx="9" cy="9" r="6" stroke="currentColor" stroke-width="1.5"/><path d="M17 17L13.5 13.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg></div>
      <h4>No opportunities available yet.</h4>
      <p>New researched opportunities appear here as soon as they're published.</p>
    </div>`;
}

function renderResults(rows, savedMap) {
  resultsEl.innerHTML = `<div class="opp-grid">${rows.map((o) => {
    const isSaved = !!savedMap[o.id];
    return `
    <div class="opp-card" data-id="${o.id}">
      <div class="opp-top">
        <div>
          <div class="company">${escapeHtml(o.company_name)}</div>
          <div class="meta">${escapeHtml(o.industry || "—")} · ${escapeHtml(o.city || "")}${o.city && o.country ? ", " : ""}${escapeHtml(o.country || "")}</div>
        </div>
        <span class="badge badge-gray">${escapeHtml(isSaved ? savedMap[o.id] : "NEW")}</span>
      </div>
      <div class="need">${escapeHtml(o.potential_need || o.description || "—")}</div>
      <div class="score-row">
        <span class="score-num">${o.opportunity_score ?? "—"}</span>
        <span class="meta">/ 100 research score</span>
      </div>
      <div class="actions">
        <a href="/opportunity.html?id=${o.id}" class="btn btn-outline btn-sm">View Details</a>
        <button class="btn ${isSaved ? "btn-outline" : "btn-primary"} btn-sm save-btn" data-saved="${isSaved}">${isSaved ? "Saved ✓" : "Save Opportunity"}</button>
      </div>
    </div>`;
  }).join("")}</div>`;

  resultsEl.querySelectorAll(".save-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const card = btn.closest(".opp-card");
      const id = card.dataset.id;
      const alreadySaved = btn.dataset.saved === "true";
      btn.disabled = true;
      if (alreadySaved) {
        await removeSavedOpportunity(id);
        btn.textContent = "Save Opportunity";
        btn.dataset.saved = "false";
        btn.classList.remove("btn-outline"); btn.classList.add("btn-primary");
      } else {
        await saveOpportunity(id);
        btn.textContent = "Saved ✓";
        btn.dataset.saved = "true";
        btn.classList.remove("btn-primary"); btn.classList.add("btn-outline");
      }
      btn.disabled = false;
    });
  });
}

function renderPagination(count) {
  const totalPages = Math.max(Math.ceil(count / PAGE_SIZE), 1);
  if (totalPages <= 1) { paginationEl.style.display = "none"; return; }
  paginationEl.style.display = "flex";
  paginationEl.innerHTML = "";
  for (let p = 1; p <= totalPages; p++) {
    const btn = document.createElement("button");
    btn.textContent = p;
    if (p === state.page) btn.classList.add("active");
    btn.addEventListener("click", () => { state.page = p; load(); window.scrollTo({ top: 0, behavior: "smooth" }); });
    paginationEl.appendChild(btn);
  }
}

async function load() {
  resultsEl.innerHTML = `<div class="empty-state"><p>Loading opportunities…</p></div>`;
  const { data, count, error, savedMap } = await listOpportunities({
    search: filters.search.value,
    industry: filters.industry.value,
    country: filters.country.value,
    city: filters.city.value,
    minScore: filters.score.value,
    sort: filters.sort.value,
    page: state.page,
  });

  if (error) {
    resultsEl.innerHTML = `<div class="alert show alert-error">Couldn't load opportunities. Please refresh the page.</div>`;
    return;
  }
  if (!data.length) { renderEmpty(); paginationEl.style.display = "none"; return; }

  renderResults(data, savedMap);
  renderPagination(count);
}

async function loadFilterOptions() {
  const { industries, countries, cities } = await getFilterOptions();
  const fill = (select, values) => {
    values.forEach((v) => {
      const opt = document.createElement("option");
      opt.value = v; opt.textContent = v;
      select.appendChild(opt);
    });
  };
  fill(filters.industry, industries);
  fill(filters.country, countries);
  fill(filters.city, cities);
}

loadFilterOptions();
load();
