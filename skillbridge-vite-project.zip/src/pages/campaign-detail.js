import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import {
  getCampaign, updateCampaign, deleteCampaign, setCampaignStatus,
  listCampaignOpportunities, removeOpportunityFromCampaign, canTransition,
} from "../data/campaigns.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();

await mountAppShell({
  activeKey: "campaigns",
  pageTitle: "Campaign Details",
  user: session.user,
  displayName: profile?.full_name?.trim() || session.user.email,
});

const wrap = document.getElementById("campaignDetailWrap");
const params = new URLSearchParams(window.location.search);
const id = params.get("id");

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

const NEXT_ACTIONS = {
  DRAFT: [{ to: "READY", label: "Mark Ready" }],
  READY: [{ to: "ACTIVE", label: "Activate" }, { to: "DRAFT", label: "Back to Draft" }],
  ACTIVE: [{ to: "PAUSED", label: "Pause" }, { to: "COMPLETED", label: "Mark Completed" }],
  PAUSED: [{ to: "ACTIVE", label: "Resume" }],
  COMPLETED: [],
  ARCHIVED: [],
};

async function render() {
  if (!id) { wrap.innerHTML = emptyState("Missing campaign ID."); return; }

  const { data: campaign, error } = await getCampaign(id);
  if (error || !campaign) { wrap.innerHTML = emptyState("This campaign is no longer available."); return; }

  const { data: oppRows } = await listCampaignOpportunities(id);

  wrap.innerHTML = `
    <div class="card">
      <div class="card-row" style="align-items:flex-start">
        <div>
          <h2 id="campName" style="font-size:22px">${escapeHtml(campaign.name)}</h2>
          <p id="campDesc" style="color:var(--ink-soft); margin-top:6px; font-size:13.5px">${escapeHtml(campaign.description || "No description.")}</p>
          <div style="margin-top:10px; display:flex; gap:16px; font-size:12.5px; color:var(--ink-soft)">
            <span>Channel: <b style="color:var(--navy)">${escapeHtml(campaign.channel)}</b></span>
            <span>Created: ${fmtDate(campaign.created_at)}</span>
            <span>Updated: ${fmtDate(campaign.updated_at)}</span>
          </div>
        </div>
        <span class="badge badge-navy" id="campStatusBadge">${campaign.status}</span>
      </div>

      <div style="display:flex; gap:8px; margin-top:18px; flex-wrap:wrap" id="actionButtons"></div>
      <div class="alert" id="campAlert"></div>
    </div>

    ${campaign.channel !== null ? `
    <div class="card" style="margin-top:16px; background:var(--bg-soft)">
      <p style="font-size:13px; color:var(--ink-soft)">📣 Outreach automation coming soon. Activating a campaign here only marks it ready for outreach preparation — no messages are sent.</p>
    </div>` : ""}

    <div class="card" style="margin-top:16px">
      <div class="card-row">
        <h3 style="font-size:15px">Selected Opportunities (${oppRows.length})</h3>
        <a href="opportunities.html" class="btn btn-outline btn-sm">+ Add More</a>
      </div>
      <div id="campOppList" style="margin-top:14px"></div>
    </div>
  `;

  renderActionButtons(campaign);
  renderOpportunities(oppRows, campaign.id);

  document.getElementById("editCampBtn").addEventListener("click", async () => {
    const newName = prompt("Campaign name:", campaign.name);
    if (newName === null) return;
    const newDesc = prompt("Description:", campaign.description || "");
    const { error } = await updateCampaign(campaign.id, { name: newName.trim() || campaign.name, description: newDesc });
    if (!error) render();
  });
}

function renderActionButtons(campaign) {
  const wrap = document.getElementById("actionButtons");
  const actions = NEXT_ACTIONS[campaign.status] || [];
  const alertBox = document.getElementById("campAlert");

  wrap.innerHTML = actions.map((a) => `<button class="btn btn-outline btn-sm" data-to="${a.to}">${a.label}</button>`).join("")
    + `<button class="btn btn-outline btn-sm" id="editCampBtn">Edit Campaign</button>`
    + `<button class="btn btn-outline btn-sm" id="archiveBtn">Archive</button>`
    + `<button class="btn btn-danger btn-sm" id="deleteBtn">Delete</button>`;

  wrap.querySelectorAll("[data-to]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      const { error } = await setCampaignStatus(campaign.id, campaign.status, btn.dataset.to);
      btn.disabled = false;
      if (error) {
        alertBox.textContent = error.message;
        alertBox.className = "alert show alert-error";
        return;
      }
      render();
    });
  });

  document.getElementById("archiveBtn").addEventListener("click", async () => {
    if (canTransition(campaign.status, "ARCHIVED") === false && campaign.status !== "ARCHIVED") {
      // Archive is allowed from most states per spec; only block from nothing.
    }
    await updateCampaign(campaign.id, { status: "ARCHIVED" });
    render();
  });

  document.getElementById("deleteBtn").addEventListener("click", async () => {
    if (!confirm("Delete this campaign permanently?")) return;
    await deleteCampaign(campaign.id);
    window.location.href = "campaigns.html";
  });
}

function renderOpportunities(rows, campaignId) {
  const listEl = document.getElementById("campOppList");
  if (!rows.length) {
    listEl.innerHTML = `<div class="empty-state" style="padding:24px 0"><p>No opportunities in this campaign yet.</p></div>`;
    return;
  }

  listEl.innerHTML = rows.map((row) => {
    const o = row.opportunity;
    if (!o) return "";
    return `
      <div class="card-row" style="padding:12px 0; border-top:1px solid var(--hair)">
        <div>
          <div style="font-weight:600; color:var(--navy); font-size:13.5px">${escapeHtml(o.company_name)}</div>
          <div style="font-size:12px; color:var(--ink-soft)">${escapeHtml(o.industry || "—")} · ${escapeHtml([o.city, o.country].filter(Boolean).join(", ") || "—")} · ${escapeHtml(o.potential_need || "—")}</div>
        </div>
        <div style="display:flex; align-items:center; gap:10px">
          <a href="opportunity.html?id=${o.id}" class="btn btn-outline btn-sm">View</a>
          <button class="btn btn-danger btn-sm remove-opp-btn" data-opp="${o.id}">Remove</button>
        </div>
      </div>`;
  }).join("");

  listEl.querySelectorAll(".remove-opp-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (!confirm("Remove this opportunity from the campaign?")) return;
      await removeOpportunityFromCampaign(campaignId, btn.dataset.opp);
      render();
    });
  });
}

function emptyState(message) {
  return `<div class="empty-state"><h4>${escapeHtml(message)}</h4></div>`;
}

render();
