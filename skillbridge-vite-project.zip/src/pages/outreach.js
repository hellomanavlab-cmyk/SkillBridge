import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import { listCampaigns } from "../data/campaigns.js";
import { listCampaignOpportunities } from "../data/campaigns.js";
import {
  getOutreachCounts, ensureOutreachContact, listOutreachContacts, setContactStatus,
  getOutreachSettings, saveOutreachSettings,
} from "../data/outreach.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();

await mountAppShell({
  activeKey: "outreach",
  pageTitle: "Outreach Agent",
  user: session.user,
  displayName: profile?.full_name?.trim() || session.user.email,
});

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ---- Stats ----
const counts = await getOutreachCounts();
document.getElementById("stTotalCampaigns").textContent = counts.totalCampaigns;
document.getElementById("stReadyCampaigns").textContent = counts.readyCampaigns;
document.getElementById("stContactsToReach").textContent = counts.contactsToReach;
document.getElementById("stFollowUps").textContent = counts.followUpsDue;
document.getElementById("stReplies").textContent = counts.replies;
document.getElementById("stInterested").textContent = counts.interested;

// ---- Tabs ----
document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    document.querySelectorAll(".tab-panel").forEach((p) => p.style.display = "none");
    document.getElementById("tab" + btn.dataset.tab[0].toUpperCase() + btn.dataset.tab.slice(1)).style.display = "";
    if (btn.dataset.tab === "preview") renderPreview();
  });
});

// ---- Campaign picker ----
let selectedCampaign = null;
let campaignContacts = [];

async function renderCampaignPicker() {
  const pickerEl = document.getElementById("campaignPicker");
  const { data: campaigns } = await listCampaigns({ page: 1 });
  const eligible = campaigns.filter((c) => c.status !== "ARCHIVED");

  if (!eligible.length) {
    pickerEl.innerHTML = `<div class="empty-state" style="padding:20px 0"><p>No campaigns yet. <a href="campaign-new.html" style="color:var(--teal); font-weight:600">Create one →</a></p></div>`;
    return;
  }

  pickerEl.innerHTML = eligible.map((c) => `
    <label class="select-opp-row" style="cursor:pointer">
      <input type="radio" name="campaignRadio" value="${c.id}">
      <span class="meta"><b>${escapeHtml(c.name)}</b> — ${escapeHtml(c.channel)} · ${c.campaign_opportunities?.[0]?.count ?? 0} opportunities · <span class="badge badge-navy">${c.status}</span></span>
    </label>
  `).join("");

  pickerEl.querySelectorAll('input[name="campaignRadio"]').forEach((radio) => {
    radio.addEventListener("change", () => {
      selectedCampaign = eligible.find((c) => c.id === radio.value);
      loadPrepOpportunities();
    });
  });
}

async function loadPrepOpportunities() {
  const listEl = document.getElementById("prepOppList");
  if (!selectedCampaign) {
    listEl.innerHTML = `<div class="empty-state" style="padding:20px 0"><p>Select a campaign above to see its opportunities.</p></div>`;
    return;
  }

  listEl.innerHTML = `<p style="font-size:13px; color:var(--ink-soft)">Loading…</p>`;
  const { data: rows } = await listCampaignOpportunities(selectedCampaign.id);

  if (!rows.length) {
    listEl.innerHTML = `<div class="empty-state" style="padding:20px 0"><p>This campaign has no opportunities yet. <a href="campaign-detail.html?id=${selectedCampaign.id}" style="color:var(--teal); font-weight:600">Add some →</a></p></div>`;
    return;
  }

  // Ensure an outreach_contacts row exists for each so status can be tracked.
  for (const row of rows) {
    if (row.opportunity) await ensureOutreachContact(selectedCampaign.id, row.opportunity);
  }
  const { data: contacts } = await listOutreachContacts(selectedCampaign.id);
  campaignContacts = contacts;

  listEl.innerHTML = contacts.map((c) => {
    const o = c.opportunity;
    if (!o) return "";
    return `
    <div class="card-row" style="padding:12px 0; border-top:1px solid var(--hair)">
      <div>
        <div style="font-weight:600; color:var(--navy); font-size:13.5px">${escapeHtml(o.company_name)}</div>
        <div style="font-size:12px; color:var(--ink-soft)">${escapeHtml(o.industry || "—")} · ${escapeHtml([o.city, o.country].filter(Boolean).join(", ") || "—")} · ${escapeHtml(o.potential_need || "—")}</div>
        ${o.company_website ? `<a href="${escapeHtml(o.company_website)}" target="_blank" rel="noopener" style="font-size:11.5px; color:var(--teal)">${escapeHtml(o.company_website)} ↗</a>` : ""}
      </div>
      <div style="display:flex; align-items:center; gap:8px">
        <span class="badge ${c.status === "READY" ? "badge-teal" : "badge-gray"}" id="statusBadge-${c.id}">${c.status}</span>
        <button class="btn btn-outline btn-sm ready-btn" data-id="${c.id}">Ready for Outreach</button>
        <button class="btn btn-outline btn-sm skip-btn" data-id="${c.id}">Skip</button>
      </div>
    </div>`;
  }).join("");

  listEl.querySelectorAll(".ready-btn").forEach((btn) => btn.addEventListener("click", () => markStatus(btn.dataset.id, "READY")));
  listEl.querySelectorAll(".skip-btn").forEach((btn) => btn.addEventListener("click", () => markStatus(btn.dataset.id, "NOT_READY")));
}

async function markStatus(contactId, status) {
  await setContactStatus(contactId, status);
  const badge = document.getElementById(`statusBadge-${contactId}`);
  if (badge) { badge.textContent = status; badge.className = `badge ${status === "READY" ? "badge-teal" : "badge-gray"}`; }
  const contact = campaignContacts.find((c) => c.id === contactId);
  if (contact) contact.status = status;
}

// ---- Message preview (template placeholders only — no AI, no sending) ----
function renderPreview() {
  const wrap = document.getElementById("previewList");
  const readyContacts = campaignContacts.filter((c) => c.status === "READY");

  if (!readyContacts.length) {
    wrap.innerHTML = `<div class="empty-state" style="padding:20px 0"><p>Mark opportunities "Ready for Outreach" in the Prepare tab to preview messages for them.</p></div>`;
    return;
  }

  wrap.innerHTML = readyContacts.map((c) => `
    <div class="card" style="margin-top:12px; background:var(--bg-soft)">
      <div style="font-weight:700; color:var(--navy); font-size:13.5px">${escapeHtml(c.opportunity?.company_name || c.company_name)}</div>
      <div class="field"><label>Subject</label><input type="text" placeholder="e.g. Quick idea for {{company_name}}" data-template="subject"></div>
      <div class="field"><label>Message</label><textarea placeholder="Write your outreach template — personalize manually for now." data-template="body"></textarea></div>
    </div>
  `).join("");
}

// ---- Settings ----
const settings = getOutreachSettings();
document.getElementById("settingsChannel").value = settings.primaryChannel;
document.getElementById("dayInitial").value = settings.schedule.initial;
document.getElementById("dayF1").value = settings.schedule.followUp1;
document.getElementById("dayF2").value = settings.schedule.followUp2;
document.getElementById("dayF3").value = settings.schedule.followUp3;

document.getElementById("saveSettingsBtn").addEventListener("click", () => {
  saveOutreachSettings({
    primaryChannel: document.getElementById("settingsChannel").value,
    schedule: {
      initial: Number(document.getElementById("dayInitial").value) || 0,
      followUp1: Number(document.getElementById("dayF1").value) || 3,
      followUp2: Number(document.getElementById("dayF2").value) || 7,
      followUp3: Number(document.getElementById("dayF3").value) || 14,
    },
  });
  const alertBox = document.getElementById("settingsAlert");
  alertBox.textContent = "Settings saved on this device.";
  alertBox.className = "alert show alert-success";
});

renderCampaignPicker();
loadPrepOpportunities();
