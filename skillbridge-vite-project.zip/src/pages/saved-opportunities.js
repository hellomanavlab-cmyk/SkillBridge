import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import { listSavedOpportunities, removeSavedOpportunity, updateRelationship, PAGE_SIZE } from "../data/opportunities.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();

await mountAppShell({
  activeKey: "opportunities",
  pageTitle: "Saved Opportunities",
  user: session.user,
  displayName: profile?.full_name?.trim() || session.user.email,
});

const resultsEl = document.getElementById("savedResults");
const paginationEl = document.getElementById("pagination");
let page = 1;

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

const STATUS_OPTIONS = ["NEW", "SAVED", "CONTACTED", "FOLLOW_UP", "REPLIED", "INTERESTED", "MEETING", "WON", "LOST", "NOT_INTERESTED"];

async function load() {
  resultsEl.innerHTML = `<div class="empty-state"><p>Loading…</p></div>`;
  const { data, count, error } = await listSavedOpportunities({ page });

  if (error) {
    resultsEl.innerHTML = `<div class="alert show alert-error">Couldn't load your saved opportunities.</div>`;
    return;
  }
  if (!data.length) {
    resultsEl.innerHTML = `
      <div class="empty-state">
        <div class="e-ico"><svg width="22" height="22" viewBox="0 0 20 20" fill="none"><path d="M5 3H15V17L10 14L5 17V3Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg></div>
        <h4>You haven't saved any opportunities yet.</h4>
        <p><a href="/opportunities.html" style="color:var(--teal); font-weight:600">Explore opportunities →</a></p>
      </div>`;
    paginationEl.style.display = "none";
    return;
  }

  resultsEl.innerHTML = `<div class="opp-grid">${data.map((row) => {
    const o = row.opportunity;
    if (!o) return "";
    return `
    <div class="opp-card" data-rel-id="${row.id}" data-opp-id="${o.id}">
      <div class="opp-top">
        <div>
          <div class="company">${escapeHtml(o.company_name)}</div>
          <div class="meta">${escapeHtml(o.industry || "—")} · ${escapeHtml([o.city, o.country].filter(Boolean).join(", ") || "—")}</div>
        </div>
        <span class="score-num">${o.opportunity_score ?? "—"}</span>
      </div>
      <div class="field" style="margin-top:0">
        <select class="status-select">
          ${STATUS_OPTIONS.map((s) => `<option value="${s}" ${s === row.status ? "selected" : ""}>${s}</option>`).join("")}
        </select>
      </div>
      <div class="actions">
        <a href="/opportunity.html?id=${o.id}" class="btn btn-outline btn-sm">View</a>
        <button class="btn btn-danger btn-sm remove-btn">Remove</button>
      </div>
    </div>`;
  }).join("")}</div>`;

  resultsEl.querySelectorAll(".opp-card").forEach((card) => {
    const oppId = card.dataset.oppId;
    card.querySelector(".status-select").addEventListener("change", (e) => {
      updateRelationship(oppId, { status: e.target.value });
    });
    card.querySelector(".remove-btn").addEventListener("click", async () => {
      if (!confirm("Remove this saved opportunity?")) return;
      await removeSavedOpportunity(oppId);
      load();
    });
  });

  renderPagination(count);
}

function renderPagination(count) {
  const totalPages = Math.max(Math.ceil(count / PAGE_SIZE), 1);
  if (totalPages <= 1) { paginationEl.style.display = "none"; return; }
  paginationEl.style.display = "flex";
  paginationEl.innerHTML = "";
  for (let p = 1; p <= totalPages; p++) {
    const btn = document.createElement("button");
    btn.textContent = p;
    if (p === page) btn.classList.add("active");
    btn.addEventListener("click", () => { page = p; load(); });
    paginationEl.appendChild(btn);
  }
}

load();
