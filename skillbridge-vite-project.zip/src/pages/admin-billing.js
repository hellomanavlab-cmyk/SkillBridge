import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";
import { supabase } from "../supabase-client.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");

await mountAdminShell({ activeKey: "billing", pageTitle: "Billing" });

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

async function load() {
  const resultsEl = document.getElementById("adminBillingResults");
  const { data: subs, error } = await supabase
    .from("subscriptions")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(100);

  if (error) { resultsEl.innerHTML = `<div class="alert show alert-error">Couldn't load subscriptions.</div>`; return; }
  if (!subs?.length) { resultsEl.innerHTML = `<div class="empty-state"><h4>No subscriptions yet.</h4></div>`; return; }

  const userIds = [...new Set(subs.map((s) => s.user_id))];
  const { data: users } = await supabase.from("profiles").select("id, full_name, email").in("id", userIds);
  const userOf = (id) => users?.find((u) => u.id === id);

  resultsEl.innerHTML = `
    <table class="data-table">
      <thead><tr><th>User</th><th>Plan</th><th>Status</th><th>Billing Cycle</th><th>Started</th><th>Expires</th></tr></thead>
      <tbody>
        ${subs.map((s) => {
          const u = userOf(s.user_id);
          return `<tr>
            <td>${escapeHtml(u?.full_name || u?.email || "—")}</td>
            <td><span class="badge badge-gray">${s.plan}</span></td>
            <td><span class="badge ${s.status === "ACTIVE" ? "badge-teal" : "badge-gray"}">${s.status}</span></td>
            <td>${escapeHtml(s.billing_cycle || "—")}</td>
            <td>${fmtDate(s.started_at)}</td>
            <td>${fmtDate(s.expires_at)}</td>
          </tr>`;
        }).join("")}
      </tbody>
    </table>
  `;
}

load();
