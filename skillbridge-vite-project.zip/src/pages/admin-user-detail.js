import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";
import { getUserDetail, setUserAccountStatus } from "../data/admin-users.js";
import { logAdminAction } from "../data/billing.js";
import { PLANS } from "../plans.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");

await mountAdminShell({ activeKey: "users", pageTitle: "User Detail" });

const wrap = document.getElementById("userDetailWrap");
const params = new URLSearchParams(window.location.search);
const userId = params.get("id");

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

async function render() {
  if (!userId) { wrap.innerHTML = `<div class="empty-state"><h4>Missing user ID.</h4></div>`; return; }

  const { profile, subscription, oppCount, campaignCount } = await getUserDetail(userId);
  if (!profile) { wrap.innerHTML = `<div class="empty-state"><h4>User not found.</h4></div>`; return; }

  const plan = PLANS[subscription?.plan] || PLANS.FREE;

  wrap.innerHTML = `
    <div class="card">
      <div class="card-row" style="align-items:flex-start">
        <div>
          <h2 style="font-size:20px">${escapeHtml(profile.full_name || "Unnamed user")}</h2>
          <div style="font-size:13.5px; color:var(--ink-soft); margin-top:4px">${escapeHtml(profile.email)}</div>
          <div style="font-size:12.5px; color:var(--ink-soft); margin-top:6px">Joined ${fmtDate(profile.created_at)}</div>
        </div>
        <span class="badge ${profile.account_status === "ACTIVE" ? "badge-teal" : "badge-red"}" id="statusBadge">${profile.account_status}</span>
      </div>
      <div style="display:flex; gap:8px; margin-top:16px">
        ${profile.account_status === "ACTIVE"
          ? `<button class="btn btn-danger btn-sm" id="suspendBtn">Suspend Account</button>`
          : `<button class="btn btn-primary btn-sm" id="reactivateBtn">Reactivate Account</button>`}
      </div>
      <div class="alert" id="statusAlert"></div>
    </div>

    <div class="card" style="margin-top:16px">
      <h3 style="font-size:15px">Profile</h3>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:12px; font-size:13.5px">
        <div><span style="color:var(--ink-soft)">Phone:</span> ${escapeHtml(profile.phone || "—")}</div>
        <div><span style="color:var(--ink-soft)">Country:</span> ${escapeHtml(profile.country || "—")}</div>
        <div><span style="color:var(--ink-soft)">City:</span> ${escapeHtml(profile.city || "—")}</div>
        <div><span style="color:var(--ink-soft)">Main skill:</span> ${escapeHtml(profile.main_skill || "—")}</div>
        <div><span style="color:var(--ink-soft)">Services:</span> ${escapeHtml(profile.services || "—")}</div>
        <div><span style="color:var(--ink-soft)">Portfolio:</span> ${escapeHtml(profile.portfolio_url || "—")}</div>
      </div>
    </div>

    <div class="card" style="margin-top:16px">
      <h3 style="font-size:15px">Subscription</h3>
      <div style="margin-top:10px; font-size:13.5px">Plan: <b>${plan.name}</b> · Status: <b>${subscription?.status || "ACTIVE"}</b></div>
    </div>

    <div class="stat-grid" style="grid-template-columns:repeat(2,1fr); margin-top:16px">
      <div class="stat-card"><div class="num">${oppCount}</div><div class="lbl">Saved Opportunities</div></div>
      <div class="stat-card"><div class="num">${campaignCount}</div><div class="lbl">Campaigns</div></div>
    </div>
  `;

  document.getElementById("suspendBtn")?.addEventListener("click", () => changeStatus("SUSPENDED"));
  document.getElementById("reactivateBtn")?.addEventListener("click", () => changeStatus("ACTIVE"));
}

async function changeStatus(newStatus) {
  const label = newStatus === "SUSPENDED" ? "suspend" : "reactivate";
  if (!confirm(`Are you sure you want to ${label} this account?`)) return;

  const { error } = await setUserAccountStatus(userId, newStatus);
  const alertBox = document.getElementById("statusAlert");
  if (error) {
    alertBox.textContent = "Couldn't update account status.";
    alertBox.className = "alert show alert-error";
    return;
  }
  await logAdminAction(newStatus === "SUSPENDED" ? "ACCOUNT_SUSPENDED" : "ACCOUNT_REACTIVATED", {
    targetType: "user", targetId: userId,
  });
  render();
}

render();
