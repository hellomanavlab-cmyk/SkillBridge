import { requireAuth, logOutUser } from "../auth.js";
import { getMyProfile, updateMyProfile } from "../profile.js";

const session = await requireAuth();
if (!session) {
  // requireAuth() has already redirected to /login.html
  throw new Error("no session");
}

const form = document.getElementById("profileForm");
const saveBtn = document.getElementById("saveBtn");
const alertBox = document.getElementById("profileAlert");

const FIELD_IDS = [
  "full_name", "phone", "country", "city", "main_skill", "services",
  "portfolio_url", "experience", "target_industries", "target_countries",
  "preferred_market", "company", "avatar_url",
];

function showAlert(type, message) {
  alertBox.textContent = message;
  alertBox.className = `alert show alert-${type}`;
}
function setLoading(isLoading, label) {
  saveBtn.disabled = isLoading;
  saveBtn.classList.toggle("loading", isLoading);
  saveBtn.querySelector(".btn-text").textContent = isLoading ? "Saving…" : label || "Save Changes";
}

async function loadProfile() {
  const { data, error } = await getMyProfile();
  if (error) {
    showAlert("error", "Couldn't load your profile. Please refresh the page.");
    return;
  }
  document.getElementById("email").value = session.user.email;
  if (data) {
    FIELD_IDS.forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.value = data[id] || "";
    });
  }
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  alertBox.className = "alert";

  const fields = {};
  FIELD_IDS.forEach((id) => {
    fields[id] = document.getElementById(id).value;
  });

  setLoading(true);
  const { error } = await updateMyProfile(fields);
  setLoading(false);

  if (error) {
    showAlert("error", "Couldn't save your changes. Please try again.");
    return;
  }
  showAlert("success", "Profile updated.");
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
  await logOutUser();
  window.location.replace("/login.html");
});

loadProfile();
