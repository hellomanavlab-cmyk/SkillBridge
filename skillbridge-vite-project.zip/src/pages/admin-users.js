import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";
import { listUsers, PAGE_SIZE } from "../data/admin-users.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");

await mountAdminShell({ activeKey: "users", pageTitle: "Users" });

const resultsEl = document.getElementById("usersResults");
const paginationEl = document.getElementById("pagination");
const searchInput = document.getElementById("uSearch");
const planSelect = document.getElementById("uPlan");
const statusSelect = document.getElementById("uStatus");
let page = 1;
let searchDebounce;

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

searchInput.addEventListener("input", () => { clearTimeout(searchDebounce); searchDebounce = setTimeout(() => { page = 1; load(); }, 350); });
planSelect.addEventListener("change", () => { page = 1; load(); });
statusSelect.addEventListener("change", () => { page = 1; load(); });

async function load() {
  resultsEl.innerHTML = `<div class="empty-state"><p>Loading…</p></div>`;
  const { data, count, error } = await listUsers({
    search: searchInput.value, plan: planSelect.value, status: statusSelect.value, page,
  });

  if (error) { resultsEl.innerHTML = `<div class="alert show alert-error">Couldn't load users.</div>`; return; }
  if (!data.length) { resultsEl.innerHTML = `<div class="empty-state"><h4>No users found.</h4></div>`; paginationEl.style.display = "none"; return; }

  resultsEl.innerHTML = `
    <table class="data-table">
      <thead><tr><th>Name</th><th>Email</th><th>Location</th><th>Main Skill</th><th>Plan</th><th>Status</th><th>Joined</th><th></th></tr></thead>
      <tbody>
        ${data.map((u) => `
          <tr>
            <td>${escapeHtml(u.full_name || "—")}</td>
            <td>${escapeHtml(u.email)}</td>
            <td>${escapeHtml([u.city, u.country].filter(Boolean).join(", ") || "—")}</td>
            <td>${escapeHtml(u.main_skill || "—")}</td>
            <td><span class="badge badge-gray">${u.plan}</span></td>
            <td><span class="badge ${u.account_status === "ACTIVE" ? "badge-teal" : "badge-red"}">${u.account_status}</span></td>
            <td>${fmtDate(u.created_at)}</td>
            <td><a href="/admin-user-detail.html?id=${u.id}" class="btn btn-outline btn-sm">View</a></td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;

  renderPagination(count);
}

function renderPagination(count) {
  const totalPages = Math.max(Math.ceil(count / PAGE_SIZE), 1);
  if (totalPages <= 1) { paginationEl.style.display = "none"; return; }
  paginationEl.style.display = "flex";
  paginationEl.innerHTML = "";
  for (let p = 1; p <= totalPages; p++) {
    const btn = document.createElement("button");
    btn.textContent = p;
    if (p === page) btn.classList.add("active");
    btn.addEventListener("click", () => { page = p; load(); });
    paginationEl.appendChild(btn);
  }
}

load();
