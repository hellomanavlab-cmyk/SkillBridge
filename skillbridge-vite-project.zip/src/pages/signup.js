import { signUpUser, isValidEmail, passwordIssue, friendlyAuthError, redirectIfAuthenticated } from "../auth.js";

redirectIfAuthenticated();

const form = document.getElementById("signupForm");
const btn = document.getElementById("signupBtn");
const alertBox = document.getElementById("signupAlert");

function showAlert(type, message) {
  alertBox.textContent = message;
  alertBox.className = `alert show alert-${type}`;
}
function clearAlert() {
  alertBox.className = "alert";
}
function showFieldError(id, message) {
  const input = document.getElementById(id);
  const err = document.getElementById(id + "Err");
  input.classList.add("error");
  if (err) { err.textContent = message; err.classList.add("show"); }
}
function clearFieldErrors() {
  form.querySelectorAll("input").forEach((el) => el.classList.remove("error"));
  form.querySelectorAll(".field-err").forEach((el) => el.classList.remove("show"));
}
function setLoading(isLoading) {
  btn.disabled = isLoading;
  btn.classList.toggle("loading", isLoading);
  btn.querySelector(".btn-text").textContent = isLoading ? "Creating account…" : "Create Account";
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearAlert();
  clearFieldErrors();

  const fullName = document.getElementById("fullName").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;
  const policyAccepted = document.getElementById("policy").checked;

  let hasError = false;

  if (!fullName) { showFieldError("fullName", "Please enter your full name."); hasError = true; }
  if (!email || !isValidEmail(email)) { showFieldError("email", "Please enter a valid email address."); hasError = true; }

  const pwIssue = password ? passwordIssue(password) : "Please enter a password.";
  if (pwIssue) { showFieldError("password", pwIssue); hasError = true; }

  if (password !== confirmPassword) { showFieldError("confirmPassword", "Passwords do not match."); hasError = true; }
  if (!policyAccepted) { showFieldError("policy", "Please accept the Terms and Privacy Policy."); hasError = true; }

  if (hasError) return;

  setLoading(true);
  const { data, error } = await signUpUser({ fullName, email, password });
  setLoading(false);

  if (error) {
    showAlert("error", friendlyAuthError(error));
    return;
  }

  // If email confirmation is required, Supabase returns a user with an
  // empty session (data.session is null) until they click the link.
  if (data?.user && !data.session) {
    showAlert(
      "success",
      "Account created. We've sent a confirmation link to your email — please verify your address before logging in."
    );
    form.reset();
    return;
  }

  // Email confirmation disabled in project settings: session exists immediately.
  if (data?.session) {
    window.location.replace("/dashboard.html");
    return;
  }

  showAlert("success", "Account created. You can now log in.");
  form.reset();
});
