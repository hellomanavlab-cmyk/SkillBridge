import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import { getOpportunityAnalytics, getCampaignAnalytics, getChannelAnalytics, rangeToDate } from "../data/analytics.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();

await mountAppShell({
  activeKey: "analytics",
  pageTitle: "Analytics",
  user: session.user,
  displayName: profile?.full_name?.trim() || session.user.email,
});

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function pct(n, total) {
  if (!total) return null;
  return Math.round((n / total) * 100);
}

const STATUS_LABELS = {
  NEW: "New", SAVED: "Saved", CONTACTED: "Contacted", FOLLOW_UP: "Follow-up", REPLIED: "Replied",
  INTERESTED: "Interested", MEETING: "Meeting", WON: "Won", LOST: "Lost", NOT_INTERESTED: "Not Interested",
};

async function load() {
  const range = document.getElementById("rangeSelect").value;
  const since = rangeToDate(range);

  const opp = await getOpportunityAnalytics(since);
  document.getElementById("stTotal").textContent = opp.total;
  document.getElementById("stSaved").textContent = opp.byStatus.SAVED;
  document.getElementById("stContacted").textContent = opp.byStatus.CONTACTED;
  document.getElementById("stFollowUp").textContent = opp.byStatus.FOLLOW_UP;
  document.getElementById("stReplies").textContent = opp.byStatus.REPLIED;
  document.getElementById("stInterested").textContent = opp.byStatus.INTERESTED;
  document.getElementById("stMeetings").textContent = opp.byStatus.MEETING;
  document.getElementById("stWon").textContent = opp.byStatus.WON;
  document.getElementById("stLost").textContent = opp.byStatus.LOST;

  const breakdownEl = document.getElementById("pipelineBreakdown");
  if (!opp.relCount) {
    breakdownEl.innerHTML = `<div class="empty-state" style="padding:20px 0"><p>No opportunity activity in this period yet.</p></div>`;
  } else {
    breakdownEl.innerHTML = Object.entries(opp.byStatus).map(([status, count]) => {
      const p = pct(count, opp.relCount);
      return `
        <div style="margin-top:10px">
          <div class="card-row" style="font-size:13px"><span>${STATUS_LABELS[status]}</span><span style="color:var(--ink-soft)">${count}${p !== null ? ` (${p}%)` : ""}</span></div>
          <div class="progress-track" style="margin-top:5px"><div class="progress-fill" style="width:${p || 0}%"></div></div>
        </div>`;
    }).join("");
  }

  const campaignEl = document.getElementById("campaignAnalytics");
  const campaigns = await getCampaignAnalytics();
  if (!campaigns.length) {
    campaignEl.innerHTML = `<div class="empty-state" style="padding:20px 0"><p>No campaigns yet.</p></div>`;
  } else {
    campaignEl.innerHTML = `
      <table class="data-table">
        <thead><tr><th>Campaign</th><th>Channel</th><th>Status</th><th>Opps</th><th>Ready</th><th>Contacted</th><th>Replies</th><th>Interested</th><th>Meetings</th></tr></thead>
        <tbody>
          ${campaigns.map((c) => `
            <tr>
              <td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.channel)}</td>
              <td><span class="badge badge-navy">${c.status}</span></td>
              <td>${c.totalOpportunities}</td><td>${c.ready}</td><td>${c.contacted}</td><td>${c.replies}</td><td>${c.interested}</td><td>${c.meetings}</td>
            </tr>`).join("")}
        </tbody>
      </table>`;
  }

  const channelEl = document.getElementById("channelAnalytics");
  const { hasActivity, rows } = await getChannelAnalytics();
  if (!hasActivity) {
    channelEl.innerHTML = `<div class="empty-state" style="padding:20px 0"><p>No outreach activity yet.</p></div>`;
  } else {
    channelEl.innerHTML = `
      <table class="data-table">
        <thead><tr><th>Channel</th><th>Contacts</th><th>Sent</th><th>Replies</th><th>Interested</th><th>Meetings</th></tr></thead>
        <tbody>
          ${rows.map((r) => `<tr><td>${escapeHtml(r.channel)}</td><td>${r.contacts}</td><td>${r.sent}</td><td>${r.replies}</td><td>${r.interested}</td><td>${r.meetings}</td></tr>`).join("")}
        </tbody>
      </table>`;
  }
}

document.getElementById("rangeSelect").addEventListener("change", load);
load();
