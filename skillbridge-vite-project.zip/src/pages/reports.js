import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { mountAppShell } from "../layout.js";
import { getOpportunityAnalytics, getCampaignAnalytics, getChannelAnalytics, getMyOpportunityReports, rangeToDate } from "../data/analytics.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const { data: profile } = await getMyProfile();
const displayName = profile?.full_name?.trim() || session.user.email;

await mountAppShell({
  activeKey: "reports",
  pageTitle: "Reports",
  user: session.user,
  displayName,
});

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

const rangeSelect = document.getElementById("rangeSelect");
const customBar = document.getElementById("customRangeBar");
let lastReportData = null;

rangeSelect.addEventListener("change", () => {
  customBar.style.display = rangeSelect.value === "custom" ? "flex" : "none";
  if (rangeSelect.value !== "custom") load();
});
document.getElementById("applyCustomBtn").addEventListener("click", load);

function getSinceIso() {
  if (rangeSelect.value === "custom") {
    const from = document.getElementById("customFrom").value;
    return from ? new Date(from).toISOString() : null;
  }
  return rangeToDate(rangeSelect.value);
}

async function load() {
  const since = getSinceIso();
  const opp = await getOpportunityAnalytics(since);
  const campaigns = await getCampaignAnalytics();
  const { hasActivity, rows: channelRows } = await getChannelAnalytics();

  lastReportData = { opp, campaigns, channelRows, since, generatedAt: new Date() };

  const output = document.getElementById("reportOutput");
  output.innerHTML = `
    <div class="card">
      <h2 style="font-size:18px">Opportunity Report</h2>
      <p style="font-size:12px; color:var(--ink-soft); margin-top:4px">Generated ${lastReportData.generatedAt.toLocaleString()} · ${rangeLabel()}</p>
      <div class="stat-grid" style="margin-top:16px">
        <div class="stat-card"><div class="num">${opp.total}</div><div class="lbl">Total Opportunities</div></div>
        <div class="stat-card"><div class="num">${opp.relCount}</div><div class="lbl">Engaged (any status)</div></div>
        <div class="stat-card"><div class="num">${opp.byStatus.SAVED}</div><div class="lbl">Saved</div></div>
        <div class="stat-card"><div class="num">${opp.byStatus.CONTACTED}</div><div class="lbl">Contacted</div></div>
        <div class="stat-card"><div class="num">${opp.byStatus.FOLLOW_UP}</div><div class="lbl">Follow-ups</div></div>
        <div class="stat-card"><div class="num">${opp.byStatus.INTERESTED}</div><div class="lbl">Interested</div></div>
        <div class="stat-card"><div class="num">${opp.byStatus.WON}</div><div class="lbl">Won</div></div>
        <div class="stat-card"><div class="num">${opp.byStatus.LOST}</div><div class="lbl">Lost</div></div>
      </div>
    </div>

    <div class="card" style="margin-top:16px">
      <h2 style="font-size:18px">Campaign Report</h2>
      ${!campaigns.length ? `<div class="empty-state" style="padding:20px 0"><p>No campaigns yet.</p></div>` : `
        <table class="data-table">
          <thead><tr><th>Campaign</th><th>Status</th><th>Opportunities</th><th>Contacted</th><th>Replies</th><th>Interested</th><th>Meetings</th></tr></thead>
          <tbody>
            ${campaigns.map((c) => `<tr><td>${escapeHtml(c.name)}</td><td>${c.status}</td><td>${c.totalOpportunities}</td><td>${c.contacted}</td><td>${c.replies}</td><td>${c.interested}</td><td>${c.meetings}</td></tr>`).join("")}
          </tbody>
        </table>`}
    </div>

    <div class="card" style="margin-top:16px">
      <h2 style="font-size:18px">Performance Summary</h2>
      <div style="margin-top:12px; display:flex; flex-direction:column; gap:8px; font-size:13.5px">
        <div>Pipeline: <b>${opp.relCount}</b> opportunities engaged out of <b>${opp.total}</b> available.</div>
        <div>Campaign activity: <b>${campaigns.length}</b> campaign(s), <b>${campaigns.filter((c) => c.status === "ACTIVE").length}</b> active.</div>
        <div>Outreach activity: ${hasActivity ? `${channelRows.reduce((s, r) => s + r.contacts, 0)} contacts prepared across ${channelRows.length} channel(s).` : "No outreach activity yet."}</div>
      </div>
    </div>
  `;
}

function rangeLabel() {
  if (rangeSelect.value === "custom") {
    const from = document.getElementById("customFrom").value || "…";
    const to = document.getElementById("customTo").value || "today";
    return `${from} to ${to}`;
  }
  return rangeSelect.selectedOptions[0].textContent;
}

document.getElementById("printBtn").addEventListener("click", () => window.print());

document.getElementById("csvBtn").addEventListener("click", () => {
  if (!lastReportData) return;
  const { opp, campaigns } = lastReportData;
  const lines = [
    ["SkillBridge Report", rangeLabel()],
    [],
    ["Opportunity Metrics"],
    ["Metric", "Count"],
    ["Total Opportunities", opp.total],
    ...Object.entries(opp.byStatus).map(([k, v]) => [k, v]),
    [],
    ["Campaigns"],
    ["Name", "Status", "Opportunities", "Contacted", "Replies", "Interested", "Meetings"],
    ...campaigns.map((c) => [c.name, c.status, c.totalOpportunities, c.contacted, c.replies, c.interested, c.meetings]),
  ];
  const csv = lines.map((row) => row.map((cell) => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `skillbridge-report-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
});

async function loadIntelReports() {
  const listEl = document.getElementById("intelReportsList");
  const reports = await getMyOpportunityReports();
  if (!reports.length) {
    listEl.innerHTML = `<div class="empty-state" style="padding:16px 0"><p>No reports yet. Reports appear here once SkillBridge's research automation generates one for your opportunities.</p></div>`;
    return;
  }
  listEl.innerHTML = reports.map((r) => `
    <div class="card-row" style="padding:12px 0; border-top:1px solid var(--hair)">
      <div>
        <div style="font-weight:600; color:var(--navy); font-size:13.5px">${escapeHtml(r.opportunity?.company_name || "Opportunity report")}</div>
        <div style="font-size:12px; color:var(--ink-soft)">Created ${new Date(r.created_at).toLocaleDateString()} · <span class="badge ${r.generation_status === "READY" ? "badge-teal" : "badge-gray"}">${r.generation_status}</span></div>
      </div>
      <div style="display:flex; gap:8px">
        ${r.report_url ? `<a href="${escapeHtml(r.report_url)}" target="_blank" rel="noopener" class="btn btn-outline btn-sm">View Report</a><a href="${escapeHtml(r.report_url)}" download class="btn btn-primary btn-sm">Download PDF</a>` : `<span style="font-size:12px; color:var(--ink-soft)">Generating…</span>`}
      </div>
    </div>`).join("");
}
loadIntelReports();

load();
