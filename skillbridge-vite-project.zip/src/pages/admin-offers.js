import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";
import { adminListOffers, adminCreateOffer, adminUpdateOffer, adminDeleteOffer } from "../data/offers.js";
import { logAdminAction } from "../data/billing.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");
await mountAdminShell({ activeKey: "offers", pageTitle: "Offers" });

const resultsEl = document.getElementById("offersResults");
const modal = document.getElementById("offerModal");
const form = document.getElementById("offerForm");
const alertBox = document.getElementById("offerAlert");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const FIELD_MAP = { oTitle: "title", oDescription: "description", oPrice: "price", oDiscount: "discount", oCtaLabel: "cta_label", oCtaUrl: "cta_url", oStart: "start_date", oEnd: "end_date", oStatus: "status" };

function openModal(offer) {
  form.reset();
  document.getElementById("offerId").value = offer?.id || "";
  document.getElementById("offerFormTitle").textContent = offer ? "Edit Offer" : "New Offer";
  alertBox.className = "alert";
  document.getElementById("oCtaLabel").value = "Get Started";
  Object.entries(FIELD_MAP).forEach(([elId, f]) => { if (offer && offer[f] != null) document.getElementById(elId).value = offer[f]; });
  modal.style.display = "flex";
}
const closeModal = () => { modal.style.display = "none"; };
document.getElementById("newOfferBtn").addEventListener("click", () => openModal(null));
document.getElementById("closeOfferModal").addEventListener("click", closeModal);

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = document.getElementById("offerId").value;
  const payload = {};
  Object.entries(FIELD_MAP).forEach(([elId, f]) => { const v = document.getElementById(elId).value.trim(); payload[f] = v === "" ? null : v; });
  if (!payload.title) return;
  if (!payload.cta_label) payload.cta_label = "Get Started";
  const btn = document.getElementById("offerSubmitBtn");
  btn.disabled = true;
  const { data, error } = id ? await adminUpdateOffer(id, payload) : await adminCreateOffer(payload);
  btn.disabled = false;
  if (error) { alertBox.textContent = "Couldn't save the offer. " + (error.message || ""); alertBox.className = "alert show alert-error"; return; }
  logAdminAction(id ? "OFFER_UPDATED" : "OFFER_CREATED", { targetType: "offer", targetId: data?.id || id, metadata: { title: payload.title } });
  closeModal(); load();
});

async function load() {
  resultsEl.innerHTML = `<div class="empty-state"><p>Loading…</p></div>`;
  const { data, error } = await adminListOffers({ page: 1 });
  if (error) { resultsEl.innerHTML = `<div class="alert show alert-error">Couldn't load offers.</div>`; return; }
  if (!data.length) { resultsEl.innerHTML = `<div class="empty-state"><h4>No offers yet.</h4><p>Create the first one.</p></div>`; return; }
  resultsEl.innerHTML = `<table class="data-table"><thead><tr><th>Title</th><th>Price</th><th>Discount</th><th>Window</th><th>Status</th><th></th></tr></thead><tbody>${data.map((o) => `
    <tr data-id="${o.id}"><td>${esc(o.title)}</td><td>${esc(o.price || "—")}</td><td>${esc(o.discount || "—")}</td><td>${o.start_date || "—"} → ${o.end_date || "—"}</td>
    <td><span class="badge ${o.status === "ACTIVE" ? "badge-teal" : o.status === "DRAFT" ? "badge-amber" : "badge-gray"}">${o.status}</span></td>
    <td class="row-actions"><button class="btn btn-outline btn-sm edit-btn">Edit</button><button class="btn btn-danger btn-sm delete-btn">Delete</button></td></tr>`).join("")}</tbody></table>`;
  resultsEl.querySelectorAll("tr[data-id]").forEach((row) => {
    const offer = data.find((o) => o.id === row.dataset.id);
    row.querySelector(".edit-btn").addEventListener("click", () => openModal(offer));
    row.querySelector(".delete-btn").addEventListener("click", async () => {
      if (!confirm(`Delete offer "${offer.title}"?`)) return;
      const { error } = await adminDeleteOffer(offer.id);
      if (error) { alert("Couldn't delete: " + error.message); return; }
      logAdminAction("OFFER_DELETED", { targetType: "offer", targetId: offer.id, metadata: { title: offer.title } });
      load();
    });
  });
}
load();
