import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";
import { adminListOpportunities, adminCreateOpportunity, adminUpdateOpportunity, adminDeleteOpportunity, PAGE_SIZE } from "../data/opportunities.js";
import { logAdminAction } from "../data/billing.js";

const session = await requireAuth();
if (!session) throw new Error("no session");

// UI-level gate. The real enforcement is the `is_admin()` RLS check
// in Postgres — even if this redirect were somehow bypassed, every
// insert/update/delete below would still be rejected for a non-admin.
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");

await mountAdminShell({ activeKey: "opportunities", pageTitle: "Manage Opportunities" });

const resultsEl = document.getElementById("adminResults");
const paginationEl = document.getElementById("pagination");
const searchInput = document.getElementById("aSearch");
const reviewStatusFilter = document.getElementById("aReviewStatus");
const modal = document.getElementById("oppFormModal");
const form = document.getElementById("oppForm");
const formAlert = document.getElementById("formAlert");

let page = 1;
let searchDebounce;

// If we arrived from the admin global search (?search=...), prefill.
const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get("search")) searchInput.value = urlParams.get("search");

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function reviewBadgeClass(status) {
  if (status === "APPROVED") return "badge-teal";
  if (status === "PENDING_REVIEW") return "badge-amber";
  if (status === "REJECTED") return "badge-red";
  return "badge-gray";
}

const FIELD_MAP = {
  fTitle: "title", fCompany: "company_name", fWebsite: "company_website", fIndustry: "industry",
  fCountry: "country", fCity: "city", fDescription: "description", fNeed: "potential_need",
  fRelevant: "why_relevant", fApproach: "suggested_approach", fSource: "source_url",
  fScore: "opportunity_score", fStatus: "status", fReviewStatus: "review_status",
};

function openModal(opp) {
  form.reset();
  document.getElementById("oppId").value = opp?.id || "";
  document.getElementById("formTitle").textContent = opp ? "Edit Opportunity" : "New Opportunity";
  formAlert.className = "alert";
  Object.entries(FIELD_MAP).forEach(([elId, field]) => {
    if (opp && opp[field] !== undefined && opp[field] !== null) {
      document.getElementById(elId).value = opp[field];
    }
  });
  modal.style.display = "flex";
}
function closeModal() { modal.style.display = "none"; }

document.getElementById("newOppBtn").addEventListener("click", () => openModal(null));
document.getElementById("closeModalBtn").addEventListener("click", closeModal);

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = document.getElementById("oppId").value;
  const payload = {};
  Object.entries(FIELD_MAP).forEach(([elId, field]) => {
    const el = document.getElementById(elId);
    let val = el.value.trim();
    if (field === "opportunity_score") val = val === "" ? null : Number(val);
    payload[field] = val === "" ? null : val;
  });
  if (!payload.status) payload.status = "ACTIVE";
  if (!payload.review_status) payload.review_status = "APPROVED";

  const submitBtn = document.getElementById("formSubmitBtn");
  submitBtn.disabled = true;
  const { data: savedOpp, error } = id ? await adminUpdateOpportunity(id, payload) : await adminCreateOpportunity(payload);
  submitBtn.disabled = false;

  if (error) {
    formAlert.textContent = "Couldn't save. " + (error.message || "");
    formAlert.className = "alert show alert-error";
    return;
  }
  logAdminAction(id ? "OPPORTUNITY_UPDATED" : "OPPORTUNITY_CREATED", {
    targetType: "opportunity", targetId: savedOpp?.id || id, metadata: { company_name: payload.company_name },
  });
  closeModal();
  load();
});

searchInput.addEventListener("input", () => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(() => { page = 1; load(); }, 350);
});
reviewStatusFilter.addEventListener("change", () => { page = 1; load(); });

async function load() {
  resultsEl.innerHTML = `<div class="empty-state"><p>Loading…</p></div>`;
  const { data, count, error } = await adminListOpportunities({ page, search: searchInput.value, reviewStatus: reviewStatusFilter.value });

  if (error) {
    resultsEl.innerHTML = `<div class="alert show alert-error">Couldn't load opportunities.</div>`;
    return;
  }
  if (!data.length) {
    resultsEl.innerHTML = `<div class="empty-state"><h4>No opportunities yet.</h4><p>Create the first one to populate the catalog.</p></div>`;
    paginationEl.style.display = "none";
    return;
  }

  resultsEl.innerHTML = `
    <table class="data-table">
      <thead><tr><th>Company</th><th>Industry</th><th>Location</th><th>Score</th><th>Status</th><th>Review</th><th></th></tr></thead>
      <tbody>
        ${data.map((o) => `
          <tr data-id="${o.id}">
            <td>${escapeHtml(o.company_name)}</td>
            <td>${escapeHtml(o.industry || "—")}</td>
            <td>${escapeHtml([o.city, o.country].filter(Boolean).join(", ") || "—")}</td>
            <td>${o.opportunity_score ?? "—"}</td>
            <td><span class="badge ${o.status === "ACTIVE" ? "badge-teal" : o.status === "DRAFT" ? "badge-amber" : "badge-gray"}">${o.status}</span></td>
            <td><span class="badge ${reviewBadgeClass(o.review_status)}">${(o.review_status || "APPROVED").replace("_", " ")}</span></td>
            <td class="row-actions">
              <button class="btn btn-outline btn-sm edit-btn">Edit</button>
              <button class="btn btn-danger btn-sm delete-btn">Delete</button>
            </td>
          </tr>
        `).join("")}
      </tbody>
    </table>
    <div class="mobile-cards">
      ${data.map((o) => `
        <div class="card" data-id="${o.id}">
          <div class="card-row"><b>${escapeHtml(o.company_name)}</b><span class="badge badge-gray">${o.status}</span></div>
          <div style="font-size:13px; color:var(--ink-soft); margin-top:6px">${escapeHtml(o.industry || "—")} · Score ${o.opportunity_score ?? "—"} · <span class="badge ${reviewBadgeClass(o.review_status)}">${(o.review_status || "APPROVED").replace("_", " ")}</span></div>
          <div class="actions" style="margin-top:10px">
            <button class="btn btn-outline btn-sm edit-btn">Edit</button>
            <button class="btn btn-danger btn-sm delete-btn">Delete</button>
          </div>
        </div>
      `).join("")}
    </div>
  `;

  resultsEl.querySelectorAll("[data-id]").forEach((row) => {
    const oppId = row.dataset.id;
    const opp = data.find((o) => o.id === oppId);
    row.querySelector(".edit-btn").addEventListener("click", () => openModal(opp));
    row.querySelector(".delete-btn").addEventListener("click", async () => {
      if (!confirm(`Delete "${opp.company_name}"? This cannot be undone.`)) return;
      const { error } = await adminDeleteOpportunity(oppId);
      if (error) { alert("Couldn't delete: " + error.message); return; }
      logAdminAction("OPPORTUNITY_DELETED", { targetType: "opportunity", targetId: oppId, metadata: { company_name: opp.company_name } });
      load();
    });
  });

  renderPagination(count);
}

function renderPagination(count) {
  const totalPages = Math.max(Math.ceil(count / PAGE_SIZE), 1);
  if (totalPages <= 1) { paginationEl.style.display = "none"; return; }
  paginationEl.style.display = "flex";
  paginationEl.innerHTML = "";
  for (let p = 1; p <= totalPages; p++) {
    const btn = document.createElement("button");
    btn.textContent = p;
    if (p === page) btn.classList.add("active");
    btn.addEventListener("click", () => { page = p; load(); });
    paginationEl.appendChild(btn);
  }
}

load();
