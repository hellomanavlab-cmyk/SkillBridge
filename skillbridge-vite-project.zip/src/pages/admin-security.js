import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";
import { listAuditLogs, PAGE_SIZE } from "../data/audit.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");

await mountAdminShell({ activeKey: "security", pageTitle: "Security / Audit Log" });

const resultsEl = document.getElementById("auditResults");
const paginationEl = document.getElementById("pagination");
const actionFilter = document.getElementById("actionFilter");
let page = 1;

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmtDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

actionFilter.addEventListener("change", () => { page = 1; load(); });

async function load() {
  resultsEl.innerHTML = `<div class="empty-state"><p>Loading…</p></div>`;
  const { data, count, error } = await listAuditLogs({ page, action: actionFilter.value });

  if (error) { resultsEl.innerHTML = `<div class="alert show alert-error">Couldn't load audit log.</div>`; return; }
  if (!data.length) { resultsEl.innerHTML = `<div class="empty-state"><h4>No admin actions recorded yet.</h4></div>`; paginationEl.style.display = "none"; return; }

  resultsEl.innerHTML = `
    <table class="data-table">
      <thead><tr><th>Action</th><th>Admin</th><th>Target</th><th>Date</th></tr></thead>
      <tbody>
        ${data.map((row) => `
          <tr>
            <td><span class="badge badge-navy">${escapeHtml(row.action)}</span></td>
            <td>${escapeHtml(row.admin?.full_name || row.admin?.email || "—")}</td>
            <td>${escapeHtml(row.target_type || "—")}${row.target_id ? ` · ${row.target_id.slice(0, 8)}…` : ""}</td>
            <td>${fmtDateTime(row.created_at)}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;

  renderPagination(count);
}

function renderPagination(count) {
  const totalPages = Math.max(Math.ceil(count / PAGE_SIZE), 1);
  if (totalPages <= 1) { paginationEl.style.display = "none"; return; }
  paginationEl.style.display = "flex";
  paginationEl.innerHTML = "";
  for (let p = 1; p <= totalPages; p++) {
    const btn = document.createElement("button");
    btn.textContent = p;
    if (p === page) btn.classList.add("active");
    btn.addEventListener("click", () => { page = p; load(); });
    paginationEl.appendChild(btn);
  }
}

load();
