import { sendPasswordReset, isValidEmail, friendlyAuthError } from "../auth.js";

const form = document.getElementById("forgotForm");
const btn = document.getElementById("forgotBtn");
const alertBox = document.getElementById("forgotAlert");

function showAlert(type, message) {
  alertBox.textContent = message;
  alertBox.className = `alert show alert-${type}`;
}
function showFieldError(id, message) {
  const input = document.getElementById(id);
  const err = document.getElementById(id + "Err");
  input.classList.add("error");
  if (err) { err.textContent = message; err.classList.add("show"); }
}
function clearFieldErrors() {
  form.querySelectorAll("input").forEach((el) => el.classList.remove("error"));
  form.querySelectorAll(".field-err").forEach((el) => el.classList.remove("show"));
}
function setLoading(isLoading) {
  btn.disabled = isLoading;
  btn.classList.toggle("loading", isLoading);
  btn.querySelector(".btn-text").textContent = isLoading ? "Sending…" : "Send Reset Link";
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  alertBox.className = "alert";
  clearFieldErrors();

  const email = document.getElementById("email").value.trim();
  if (!email || !isValidEmail(email)) {
    showFieldError("email", "Please enter a valid email address.");
    return;
  }

  setLoading(true);
  const { error } = await sendPasswordReset(email);
  setLoading(false);

  // Supabase intentionally doesn't reveal whether the email exists, to
  // avoid leaking which addresses have accounts — so we show the same
  // success message either way, unless it's a hard error (rate limit, network).
  if (error) {
    showAlert("error", friendlyAuthError(error));
    return;
  }
  showAlert("success", "If an account exists for that email, a password reset link is on its way. Check your inbox.");
  form.reset();
});
