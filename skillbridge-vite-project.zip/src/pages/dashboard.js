import { requireAuth } from "../auth.js";
import { getMyProfile } from "../profile.js";
import { getOpportunityStats, computeProfileCompletion } from "../data/stats.js";
import { listOpportunities } from "../data/opportunities.js";
import { listCampaigns } from "../data/campaigns.js";
import { getMySubscription } from "../data/billing.js";
import { PLANS } from "../plans.js";
import { mountAppShell } from "../layout.js";

const session = await requireAuth();
if (!session) throw new Error("no session");

const { data: profile } = await getMyProfile();
const displayName = profile?.full_name?.trim() || session.user.email;

await mountAppShell({
  activeKey: "overview",
  pageTitle: "Overview",
  user: session.user,
  displayName,
});

document.getElementById("dashWelcome").textContent = `Welcome back, ${displayName}`;

// ---- Plan ----
const { data: sub } = await getMySubscription();
document.getElementById("planName").textContent = `${(PLANS[sub?.plan] || PLANS.FREE).name} Plan`;

// ---- Profile completion ----
const completion = computeProfileCompletion(profile);
if (completion < 100) {
  const card = document.getElementById("profileCompletionCard");
  card.style.display = "";
  document.getElementById("profileCompletionText").textContent = `${completion}% complete`;
  document.getElementById("profileCompletionFill").style.width = `${completion}%`;
  card.addEventListener("click", () => window.location.href = "/profile.html");
}

// ---- Stats ----
const stats = await getOpportunityStats();
document.getElementById("statTotal").textContent = stats.total;
document.getElementById("statNew").textContent = stats.newCount;
document.getElementById("statContacted").textContent = stats.contacted;
document.getElementById("statFollowUps").textContent = stats.followUpsDue;
document.getElementById("statReplies").textContent = stats.replies;
document.getElementById("statInterested").textContent = stats.interested;

// ---- Recent opportunities preview ----
const oppWrap = document.getElementById("recentOpportunities");
const { data: recentOpps } = await listOpportunities({ sort: "newest", page: 1 });
if (!recentOpps.length) {
  oppWrap.innerHTML = emptyState("No opportunities available yet.");
} else {
  oppWrap.innerHTML = recentOpps.slice(0, 4).map((o) => `
    <div style="padding:12px 0; border-top:1px solid var(--hair); display:flex; justify-content:space-between; gap:10px; align-items:center">
      <div>
        <div style="font-weight:600; color:var(--navy); font-size:13.5px">${escapeHtml(o.company_name)}</div>
        <div style="font-size:12px; color:var(--ink-soft)">${escapeHtml(o.industry || "—")} · ${escapeHtml(o.city || o.country || "—")}</div>
      </div>
      <span class="badge badge-teal">${o.opportunity_score ?? "—"}</span>
    </div>
  `).join("");
}

// ---- Active campaigns preview ----
const campWrap = document.getElementById("activeCampaigns");
const { data: campaigns } = await listCampaigns({ page: 1 });
const active = campaigns.filter((c) => c.status === "ACTIVE" || c.status === "READY");
if (!campaigns.length) {
  campWrap.innerHTML = emptyState("No active campaigns.");
} else if (!active.length) {
  campWrap.innerHTML = emptyState("No active campaigns yet — you have drafts waiting.");
} else {
  campWrap.innerHTML = active.slice(0, 4).map((c) => `
    <div style="padding:12px 0; border-top:1px solid var(--hair); display:flex; justify-content:space-between; gap:10px; align-items:center">
      <div>
        <div style="font-weight:600; color:var(--navy); font-size:13.5px">${escapeHtml(c.name)}</div>
        <div style="font-size:12px; color:var(--ink-soft)">${escapeHtml(c.channel)} · ${c.campaign_opportunities?.[0]?.count ?? 0} opportunities</div>
      </div>
      <span class="badge badge-navy">${c.status}</span>
    </div>
  `).join("");
}

// ---- Recent activity (no real activity source yet — honest empty state) ----
document.getElementById("recentActivity").innerHTML = emptyState("No recent activity yet.");

function emptyState(message) {
  return `<div class="empty-state" style="padding:24px 0">
    <p>${escapeHtml(message)}</p>
  </div>`;
}
function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
