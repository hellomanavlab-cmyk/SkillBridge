import { logInUser, isValidEmail, friendlyAuthError, redirectIfAuthenticated } from "../auth.js";

redirectIfAuthenticated();

const form = document.getElementById("loginForm");
const btn = document.getElementById("loginBtn");
const alertBox = document.getElementById("loginAlert");

function showAlert(type, message) {
  alertBox.textContent = message;
  alertBox.className = `alert show alert-${type}`;
}
function clearAlert() {
  alertBox.className = "alert";
}
function showFieldError(id, message) {
  const input = document.getElementById(id);
  const err = document.getElementById(id + "Err");
  input.classList.add("error");
  if (err) { err.textContent = message; err.classList.add("show"); }
}
function clearFieldErrors() {
  form.querySelectorAll("input").forEach((el) => el.classList.remove("error"));
  form.querySelectorAll(".field-err").forEach((el) => el.classList.remove("show"));
}
function setLoading(isLoading) {
  btn.disabled = isLoading;
  btn.classList.toggle("loading", isLoading);
  btn.querySelector(".btn-text").textContent = isLoading ? "Logging in…" : "Log In";
}

// Preserve ?next= across to the signup/forgot-password links, so the
// person lands back where they intended after finishing either flow.
const params = new URLSearchParams(window.location.search);
const next = (params.get("next") || "").replace(/^\//, ""); // strip any stale leading slash from old links
if (next) {
  document.querySelectorAll("[data-preserve-next]").forEach((a) => {
    const url = new URL(a.href, window.location.origin);
    url.searchParams.set("next", next);
    a.href = url.toString();
  });
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearAlert();
  clearFieldErrors();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  let hasError = false;
  if (!email || !isValidEmail(email)) { showFieldError("email", "Please enter a valid email address."); hasError = true; }
  if (!password) { showFieldError("password", "Please enter your password."); hasError = true; }
  if (hasError) return;

  setLoading(true);
  const { data, error } = await logInUser({ email, password });
  setLoading(false);

  if (error) {
    showAlert("error", friendlyAuthError(error));
    return;
  }

  if (data?.session) {
    window.location.replace(next || "dashboard.html");
  }
});
