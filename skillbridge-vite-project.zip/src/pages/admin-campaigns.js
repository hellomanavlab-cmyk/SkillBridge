import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";
import { supabase } from "../supabase-client.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");

await mountAdminShell({ activeKey: "campaigns", pageTitle: "Campaigns" });

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmtDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

async function load() {
  const resultsEl = document.getElementById("adminCampaignsResults");
  resultsEl.innerHTML = `<div class="empty-state"><p>Loading…</p></div>`;

  // "Admins can view all campaigns" RLS policy makes this return the
  // whole platform's campaigns for an admin, and only the caller's
  // own for anyone else — same query, safety enforced server-side.
  const { data: campaigns, error } = await supabase
    .from("campaigns")
    .select("*, campaign_opportunities(count)")
    .order("created_at", { ascending: false })
    .limit(100);

  if (error) { resultsEl.innerHTML = `<div class="alert show alert-error">Couldn't load campaigns.</div>`; return; }
  if (!campaigns?.length) { resultsEl.innerHTML = `<div class="empty-state"><h4>No campaigns on the platform yet.</h4></div>`; return; }

  const ownerIds = [...new Set(campaigns.map((c) => c.user_id))];
  const { data: owners } = await supabase.from("profiles").select("id, full_name, email").in("id", ownerIds);
  const ownerOf = (id) => owners?.find((o) => o.id === id);

  resultsEl.innerHTML = `
    <table class="data-table">
      <thead><tr><th>Campaign</th><th>Owner</th><th>Channel</th><th>Status</th><th>Opportunities</th><th>Created</th></tr></thead>
      <tbody>
        ${campaigns.map((c) => {
          const owner = ownerOf(c.user_id);
          return `<tr>
            <td>${escapeHtml(c.name)}</td>
            <td>${escapeHtml(owner?.full_name || owner?.email || "—")}</td>
            <td>${escapeHtml(c.channel)}</td>
            <td><span class="badge badge-navy">${c.status}</span></td>
            <td>${c.campaign_opportunities?.[0]?.count ?? 0}</td>
            <td>${fmtDate(c.created_at)}</td>
          </tr>`;
        }).join("")}
      </tbody>
    </table>
    <p style="font-size:12px; color:var(--ink-soft); margin-top:10px">Showing the most recent 100 campaigns platform-wide.</p>
  `;
}

load();
