import { requireAuth } from "../auth.js";
import { requireAdmin } from "../data/admin.js";
import { mountAdminShell } from "../admin-layout.js";
import { getPlatformStats, getPlanDistribution, getSignupTrend } from "../data/admin-stats.js";
import { rangeToDate } from "../data/analytics.js";

const session = await requireAuth();
if (!session) throw new Error("no session");
const admin = await requireAdmin();
if (!admin) throw new Error("not admin");

await mountAdminShell({ activeKey: "overview", pageTitle: "Platform Overview" });

const stats = await getPlatformStats();
document.getElementById("stUsers").textContent = stats.totalUsers;
document.getElementById("stActiveUsers").textContent = stats.activeUsers;
document.getElementById("stOpps").textContent = stats.totalOpportunities;
document.getElementById("stSavedOpps").textContent = stats.savedOpportunities;
document.getElementById("stCampaigns").textContent = stats.totalCampaigns;
document.getElementById("stActiveCampaigns").textContent = stats.activeCampaigns;
document.getElementById("stOutreach").textContent = stats.outreachContacts;
document.getElementById("stInterested").textContent = stats.interestedOpportunities;

const dist = await getPlanDistribution();
const total = Object.values(dist).reduce((a, b) => a + b, 0) || 1;
document.getElementById("planDistribution").innerHTML = Object.entries(dist).map(([plan, count]) => `
  <div style="margin-top:10px">
    <div class="card-row" style="font-size:13px"><span>${plan}</span><span style="color:var(--ink-soft)">${count} (${Math.round((count / total) * 100)}%)</span></div>
    <div class="progress-track" style="margin-top:5px"><div class="progress-fill" style="width:${Math.round((count / total) * 100)}%"></div></div>
  </div>
`).join("");

// ---- Signup trend — real timestamps, bucketed by day client-side ----
function bucketByDay(rows, days) {
  const buckets = [];
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    buckets.push({ key, label: d.toLocaleDateString(undefined, { month: "short", day: "numeric" }), count: 0 });
  }
  rows.forEach((row) => {
    const key = new Date(row.created_at).toISOString().slice(0, 10);
    const bucket = buckets.find((b) => b.key === key);
    if (bucket) bucket.count++;
  });
  return buckets;
}

async function loadTrend() {
  const rangeKey = document.getElementById("trendRange").value;
  const days = { "7d": 7, "30d": 30, "90d": 90 }[rangeKey] || 30;
  const since = rangeToDate(rangeKey);
  const rows = await getSignupTrend(since);
  const trendEl = document.getElementById("signupTrend");

  if (!rows.length) {
    trendEl.innerHTML = `<div class="empty-state" style="padding:20px 0"><p>No signups recorded in this period yet.</p></div>`;
    return;
  }

  const buckets = bucketByDay(rows, days);
  const max = Math.max(...buckets.map((b) => b.count), 1);
  const showEveryNth = days > 30 ? Math.ceil(days / 15) : 1;

  trendEl.innerHTML = `
    <div class="bar-chart">
      ${buckets.map((b, i) => `
        <div class="bar-col">
          ${b.count > 0 ? `<span class="bar-value">${b.count}</span>` : ""}
          <div class="bar" style="height:${(b.count / max) * 100}%"></div>
          ${i % showEveryNth === 0 ? `<span class="bar-label">${b.label}</span>` : ""}
        </div>
      `).join("")}
    </div>
    <p style="font-size:12px; color:var(--ink-soft); margin-top:12px">${rows.length} new user(s) in this period.</p>
  `;
}

document.getElementById("trendRange").addEventListener("change", loadTrend);
loadTrend();
