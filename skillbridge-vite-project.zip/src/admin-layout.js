// SkillBridge — admin shell. Deliberately styled distinct from the
// regular app shell (dark sidebar) so nobody mistakes the admin area
// for their normal dashboard. Every page that calls this has already
// passed requireAdmin() — see src/data/admin.js — which itself is
// just UX; the real enforcement is the is_admin() RLS policies.

import { logOutUser } from "./auth.js";
import { supabase } from "./supabase-client.js";

const NAV_ITEMS = [
  { key: "overview", label: "Overview", href: "/admin.html", icon: "grid" },
  { key: "users", label: "Users", href: "/admin-users.html", icon: "user" },
  { key: "opportunities", label: "Opportunities", href: "/admin-opportunities.html", icon: "target" },
  { key: "campaigns", label: "Campaigns", href: "/admin-campaigns.html", icon: "megaphone" },
  { key: "outreach", label: "Outreach", href: "/admin-outreach.html", icon: "send" },
  { key: "billing", label: "Billing", href: "/admin-billing.html", icon: "card" },
  { key: "security", label: "Security / Audit", href: "/admin-security.html", icon: "shield" },
  { key: "settings", label: "Platform Settings", href: "/admin-settings.html", icon: "settings" },
];

const ICONS = {
  grid: '<svg viewBox="0 0 20 20" fill="none"><rect x="2.5" y="2.5" width="6" height="6" rx="1.5" stroke="currentColor" stroke-width="1.5"/><rect x="11.5" y="2.5" width="6" height="6" rx="1.5" stroke="currentColor" stroke-width="1.5"/><rect x="2.5" y="11.5" width="6" height="6" rx="1.5" stroke="currentColor" stroke-width="1.5"/><rect x="11.5" y="11.5" width="6" height="6" rx="1.5" stroke="currentColor" stroke-width="1.5"/></svg>',
  user: '<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="6.8" r="3.3" stroke="currentColor" stroke-width="1.4"/><path d="M3.5 17C4.3 13.7 6.9 12 10 12C13.1 12 15.7 13.7 16.5 17" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
  target: '<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><circle cx="10" cy="10" r="3.2" stroke="currentColor" stroke-width="1.5"/></svg>',
  megaphone: '<svg viewBox="0 0 20 20" fill="none"><path d="M3 8.5V11.5L6 12.5V15.5C6 16.3 6.7 17 7.5 17C8.3 17 9 16.3 9 15.5V13L15 15V5L9 7L3 8.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>',
  send: '<svg viewBox="0 0 20 20" fill="none"><path d="M17.5 2.5L2.5 8.5L9 11L11.5 17.5L17.5 2.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>',
  card: '<svg viewBox="0 0 20 20" fill="none"><rect x="2.5" y="5" width="15" height="10" rx="1.5" stroke="currentColor" stroke-width="1.4"/><path d="M2.5 8.5H17.5" stroke="currentColor" stroke-width="1.4"/></svg>',
  shield: '<svg viewBox="0 0 20 20" fill="none"><path d="M10 2.5L16.5 5V9.5C16.5 13.5 13.7 16.7 10 17.5C6.3 16.7 3.5 13.5 3.5 9.5V5L10 2.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>',
  settings: '<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="2.6" stroke="currentColor" stroke-width="1.4"/><path d="M10 2.5V4.3M10 15.7V17.5M17.5 10H15.7M4.3 10H2.5M15.1 4.9L13.8 6.2M6.2 13.8L4.9 15.1M15.1 15.1L13.8 13.8M6.2 6.2L4.9 4.9" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
  logout: '<svg viewBox="0 0 20 20" fill="none"><path d="M8 17.5H4.5C3.9 17.5 3.5 17.1 3.5 16.5V3.5C3.5 2.9 3.9 2.5 4.5 2.5H8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M13 14L17 10L13 6M17 10H7.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
};

export async function mountAdminShell({ activeKey, pageTitle }) {
  const navHtml = NAV_ITEMS.map((item) => {
    const activeClass = item.key === activeKey ? " active" : "";
    return `<a href="${item.href}" class="${activeClass.trim()}"><span class="nav-ico">${ICONS[item.icon]}</span>${item.label}</a>`;
  }).join("");

  const shellHtml = `
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <aside class="app-sidebar admin-sidebar" id="appSidebar">
      <div class="brand admin-brand">
        <span class="skill" style="color:#fff">Skill</span><span class="bridge">Bridge</span>
        <span class="admin-pill">ADMIN</span>
      </div>
      <nav class="app-nav">${navHtml}</nav>
      <div class="sidebar-foot">
        <a href="/dashboard.html" class="admin-back-link"><span class="nav-ico">${ICONS.grid}</span>Back to App</a>
        <button class="logout-link" id="sidebarLogout">
          <span class="nav-ico">${ICONS.logout}</span>Logout
        </button>
      </div>
    </aside>

    <div class="app-main">
      <header class="app-topbar admin-topbar">
        <div style="display:flex; align-items:center; gap:14px">
          <button class="icon-btn burger-btn" id="burgerBtn" aria-label="Open menu">
            <svg width="18" height="18" viewBox="0 0 20 20" fill="none"><path d="M3 5H17M3 10H17M3 15H17" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
          </button>
          <span class="page-title">${pageTitle}</span>
        </div>
        <div style="position:relative; flex:1; max-width:340px">
          <input type="search" id="adminGlobalSearch" placeholder="Search users, opportunities, campaigns…"
            style="width:100%; padding:8px 12px; border:1px solid var(--hair); border-radius:9px; font-size:13px">
          <div id="adminSearchResults" style="display:none; position:absolute; top:40px; left:0; right:0; background:#fff; border:1px solid var(--hair); border-radius:10px; box-shadow:0 20px 50px -20px rgba(22,35,63,.35); z-index:50; max-height:340px; overflow-y:auto"></div>
        </div>
      </header>
      <div class="app-content" id="appContent"></div>
    </div>
  `;

  const existingContent = document.getElementById("page-content");
  const contentHtml = existingContent ? existingContent.innerHTML : "";

  document.body.classList.add("app-shell", "admin-mode");
  document.body.innerHTML = shellHtml;
  document.getElementById("appContent").innerHTML = contentHtml;

  wireShellEvents();
}

function wireShellEvents() {
  const sidebar = document.getElementById("appSidebar");
  const overlay = document.getElementById("sidebarOverlay");
  document.getElementById("burgerBtn")?.addEventListener("click", () => {
    sidebar.classList.add("open");
    overlay.classList.add("show");
  });
  overlay?.addEventListener("click", () => {
    sidebar.classList.remove("open");
    overlay.classList.remove("show");
  });
  document.getElementById("sidebarLogout")?.addEventListener("click", async () => {
    await logOutUser();
    window.location.replace("/login.html");
  });

  wireGlobalSearch();
}

function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function wireGlobalSearch() {
  const input = document.getElementById("adminGlobalSearch");
  const resultsBox = document.getElementById("adminSearchResults");
  let debounceTimer;

  input.addEventListener("input", () => {
    clearTimeout(debounceTimer);
    const term = input.value.trim();
    if (term.length < 2) { resultsBox.style.display = "none"; return; }
    debounceTimer = setTimeout(() => runSearch(term), 300);
  });

  document.addEventListener("click", (e) => {
    if (!resultsBox.contains(e.target) && e.target !== input) resultsBox.style.display = "none";
  });

  async function runSearch(term) {
    const like = `%${term}%`;
    // Three small, indexed, limited queries — never loads the whole
    // table into the browser just to search it.
    const [{ data: users }, { data: opps }, { data: camps }] = await Promise.all([
      supabase.from("profiles").select("id, full_name, email").or(`full_name.ilike.${like},email.ilike.${like}`).limit(5),
      supabase.from("opportunities").select("id, company_name").ilike("company_name", like).limit(5),
      supabase.from("campaigns").select("id, name").ilike("name", like).limit(5),
    ]);

    const sections = [
      { label: "Users", rows: users, href: (r) => `/admin-user-detail.html?id=${r.id}`, text: (r) => r.full_name || r.email },
      { label: "Opportunities", rows: opps, href: (r) => `/admin-opportunities.html?search=${encodeURIComponent(r.company_name)}`, text: (r) => r.company_name },
      { label: "Campaigns", rows: camps, href: () => `/admin-campaigns.html`, text: (r) => r.name },
    ].filter((s) => s.rows?.length);

    if (!sections.length) {
      resultsBox.innerHTML = `<div style="padding:14px; font-size:13px; color:#9a9fa8">No matches.</div>`;
      resultsBox.style.display = "block";
      return;
    }

    resultsBox.innerHTML = sections.map((s) => `
      <div style="padding:8px 12px 4px; font-size:11px; font-weight:700; color:#9a9fa8; text-transform:uppercase">${s.label}</div>
      ${s.rows.map((r) => `<a href="${s.href(r)}" style="display:block; padding:9px 12px; font-size:13.5px; color:var(--navy)">${escapeHtml(s.text(r))}</a>`).join("")}
    `).join("");
    resultsBox.style.display = "block";
  }
}
