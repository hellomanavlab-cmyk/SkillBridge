// SkillBridge — shared authentication helpers
// -----------------------------------------------------------------
// Wraps @supabase/supabase-js Auth calls used across the auth pages.
// Only the PUBLISHABLE key (via supabase-client.js) is used here —
// nothing in this file talks to the secret/service-role key.
// -----------------------------------------------------------------

import { supabase } from "./supabase-client.js";

/** Basic client-side email format check (Supabase re-validates server-side too). */
export function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

/** Minimum client-side password rule. Supabase's own project setting is the source of truth. */
export function passwordIssue(password) {
  if (password.length < 8) return "Password must be at least 8 characters long.";
  return null;
}

/**
 * Turns a raw Supabase AuthError into a short, friendly message.
 * Prefers the stable `error.code` field (newer supabase-js) and falls
 * back to matching `error.message` for older versions.
 */
export function friendlyAuthError(error) {
  if (!error) return "Something went wrong. Please try again.";

  const code = error.code || "";
  const msg = (error.message || "").toLowerCase();

  if (code === "invalid_credentials" || msg.includes("invalid login credentials")) {
    return "Incorrect email or password.";
  }
  if (code === "email_not_confirmed" || msg.includes("email not confirmed")) {
    return "Please verify your email before logging in — check your inbox for the confirmation link.";
  }
  if (code === "user_already_exists" || code === "email_exists" || msg.includes("already registered") || msg.includes("already exists")) {
    return "An account with this email already exists. Try logging in instead.";
  }
  if (code === "weak_password" || msg.includes("password should be at least") || msg.includes("password is too weak")) {
    return error.message || "That password is too weak. Please choose a stronger one.";
  }
  if (code === "email_address_invalid" || msg.includes("invalid") && msg.includes("email")) {
    return "That email address doesn't look valid.";
  }
  if (code === "over_email_send_rate_limit" || msg.includes("rate limit") && msg.includes("email")) {
    return "Too many requests sent to this email. Please wait a minute and try again.";
  }
  if (code === "over_request_rate_limit" || msg.includes("rate limit")) {
    return "Too many attempts. Please wait a moment and try again.";
  }
  if (code === "user_not_found") {
    return "Incorrect email or password.";
  }
  if (code === "signup_disabled") {
    return "New sign-ups are currently disabled. Please contact us for access.";
  }
  if (msg.includes("failed to fetch") || msg.includes("network")) {
    return "Network error — please check your connection and try again.";
  }
  return error.message || "Something went wrong. Please try again.";
}

/** Wraps fetch-based Supabase calls so a dropped connection shows a friendly message too. */
export async function safeAuthCall(fn) {
  try {
    return await fn();
  } catch (err) {
    return { data: null, error: { message: "Network error — please check your connection and try again." } };
  }
}

export async function signUpUser({ fullName, email, password }) {
  return safeAuthCall(() =>
    supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        data: { full_name: fullName.trim() },
        emailRedirectTo: `${window.location.origin}/login.html`,
      },
    })
  );
}

export async function logInUser({ email, password }) {
  return safeAuthCall(() =>
    supabase.auth.signInWithPassword({ email: email.trim(), password })
  );
}

export async function logOutUser() {
  return safeAuthCall(() => supabase.auth.signOut());
}

export async function sendPasswordReset(email) {
  return safeAuthCall(() =>
    supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/reset-password.html`,
    })
  );
}

export async function updatePassword(newPassword) {
  return safeAuthCall(() => supabase.auth.updateUser({ password: newPassword }));
}

export async function getSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) return null;
  return data.session;
}

/**
 * Call at the top of any page that requires a logged-in user.
 * Redirects to /login.html (preserving the original page via ?next=)
 * if there's no active session, and to /suspended.html if the
 * account has been suspended by an admin. Keeps watching for sign-out.
 */
export async function requireAuth() {
  const session = await getSession();
  if (!session) {
    const next = encodeURIComponent(window.location.pathname);
    window.location.replace(`/login.html?next=${next}`);
    return null;
  }

  const { data: profileRow } = await supabase
    .from("profiles")
    .select("account_status")
    .eq("id", session.user.id)
    .maybeSingle();

  if (profileRow?.account_status === "SUSPENDED" && window.location.pathname !== "/suspended.html") {
    window.location.replace("/suspended.html");
    return null;
  }

  supabase.auth.onAuthStateChange((event) => {
    if (event === "SIGNED_OUT") {
      window.location.replace("/login.html");
    }
  });
  return session;
}

/** Call on login/signup pages so an already-authenticated user skips straight past them. */
export async function redirectIfAuthenticated(defaultPath = "/dashboard.html") {
  const session = await getSession();
  if (session) {
    const params = new URLSearchParams(window.location.search);
    window.location.replace(params.get("next") || defaultPath);
  }
}
