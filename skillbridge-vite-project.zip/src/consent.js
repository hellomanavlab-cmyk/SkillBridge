// SkillBridge — cookie / browser-storage consent
// -----------------------------------------------------------------
// What this controls today: NOTHING optional is running on this site
// (no analytics, no marketing pixels). The banner still records a real
// choice and exposes it, so that if an optional integration is ever
// added it can be gated on the user's consent instead of firing blindly.
//
// To gate an optional script later:
//   window.SBConsent.onChange((allowed) => { if (allowed) loadMyAnalytics(); });
// onChange is also called once on page load with the stored choice.
//
// Essential storage (Supabase login session, this consent choice) is
// always allowed — it is needed for the site/app to function.
//
// Bump CONSENT_VERSION whenever the Cookie Policy or the set of optional
// integrations materially changes — everyone is then asked again.
// -----------------------------------------------------------------
import "./styles/consent.css";

const KEY = "sb_cookie_consent";
const CONSENT_VERSION = 1;
const COOKIE_POLICY_URL = "cookie-policy.html";
const listeners = new Set();
let banner = null;
let lastTrigger = null;

function readStored() {
  try {
    const v = JSON.parse(localStorage.getItem(KEY));
    if (v && v.version === CONSENT_VERSION && (v.optional === "accepted" || v.optional === "rejected")) return v;
  } catch { /* unreadable → treat as no choice */ }
  return null;
}
function write(optional) {
  const value = { version: CONSENT_VERSION, essential: true, optional, savedAt: new Date().toISOString() };
  try { localStorage.setItem(KEY, JSON.stringify(value)); } catch { /* storage blocked: choice applies to this page view only */ }
  return value;
}
function notify() {
  const allowed = readStored()?.optional === "accepted";
  listeners.forEach((cb) => { try { cb(allowed); } catch (e) { console.error(e); } });
}

function buildBanner() {
  const el = document.createElement("div");
  el.className = "sb-consent";
  el.id = "sbConsent";
  el.setAttribute("role", "region");
  el.setAttribute("aria-labelledby", "sbConsentTitle");
  el.hidden = true;
  el.innerHTML = `
    <div class="sb-consent-inner">
      <button type="button" class="sb-consent-close" aria-label="Close cookie preferences" hidden>×</button>
      <div class="sb-consent-text">
        <h2 id="sbConsentTitle">Your Privacy Matters</h2>
        <p>We use cookies to help our website function properly, understand website usage, and improve your experience. You can accept or reject optional cookies at any time.</p>
        <p class="sb-consent-status" hidden></p>
      </div>
      <div class="sb-consent-actions">
        <button type="button" class="sb-btn sb-btn-primary" data-act="accept">Accept All Cookies</button>
        <button type="button" class="sb-btn sb-btn-outline" data-act="reject">Reject Optional Cookies</button>
        <a class="sb-btn sb-btn-link" href="${COOKIE_POLICY_URL}">Cookie Policy</a>
      </div>
    </div>`;
  el.addEventListener("click", (e) => {
    const act = e.target.closest("[data-act]")?.dataset.act;
    if (act === "accept" || act === "reject") { write(act === "accept" ? "accepted" : "rejected"); hide(); notify(); }
    if (e.target.closest(".sb-consent-close")) hide();
  });
  document.body.appendChild(el);
  return el;
}

function show(reopened) {
  banner = banner || buildBanner();
  const stored = readStored();
  const closeBtn = banner.querySelector(".sb-consent-close");
  const status = banner.querySelector(".sb-consent-status");
  closeBtn.hidden = !reopened;
  status.hidden = !(reopened && stored);
  if (stored) status.textContent = `Current choice: optional cookies ${stored.optional}. Essential storage is always on.`;
  banner.hidden = false;
  if (reopened) banner.querySelector('[data-act="accept"]').focus();
}
function hide() {
  if (!banner) return;
  banner.hidden = true;
  if (lastTrigger) { lastTrigger.focus(); lastTrigger = null; }
}

window.SBConsent = {
  get: readStored,
  optionalAllowed: () => readStored()?.optional === "accepted",
  onChange(cb) { listeners.add(cb); cb(readStored()?.optional === "accepted"); return () => listeners.delete(cb); },
  openPreferences() { show(true); },
};

document.addEventListener("click", (e) => {
  const trigger = e.target.closest("[data-cookie-prefs]");
  if (trigger) { e.preventDefault(); lastTrigger = trigger; show(true); }
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && banner && !banner.hidden && !banner.querySelector(".sb-consent-close").hidden) hide();
});

if (!readStored()) show(false);
notify();
