// SkillBridge — plan configuration (single source of truth)
// -----------------------------------------------------------------
// Any page that needs to show or reason about plans imports from
// here, so pricing/feature copy never drifts out of sync across the
// billing page, dashboard, and (eventually) a public pricing page.
//
// IMPORTANT: this file has no authority over what a user actually
// has — that's the `subscriptions` table, readable only via RLS.
// This is display + feature-gating config only.
// -----------------------------------------------------------------

export const PLANS = {
  FREE: {
    key: "FREE",
    name: "Free",
    price: "₹0",
    priceSuffix: "",
    tagline: "Everything you need to get started.",
    features: [
      "Opportunity dashboard",
      "Saved opportunities",
      "Basic campaigns",
      "Basic analytics",
      "Reports",
    ],
    purchasable: true,
  },
  STARTER: {
    key: "STARTER",
    name: "Starter",
    price: "Coming Soon",
    priceSuffix: "",
    tagline: "For individuals ramping up outreach.",
    features: ["Everything in Free", "Higher opportunity limits (planned)"],
    purchasable: false,
  },
  GROWTH: {
    key: "GROWTH",
    name: "Growth",
    price: "Coming Soon",
    priceSuffix: "",
    tagline: "For teams running multiple campaigns.",
    features: ["Everything in Starter", "Outreach automation (planned)"],
    purchasable: false,
  },
  CUSTOM: {
    key: "CUSTOM",
    name: "Custom",
    price: "Contact Us",
    priceSuffix: "",
    tagline: "Tailored for agencies and larger volumes.",
    features: ["Custom opportunity volume", "Dedicated support"],
    purchasable: false,
  },
};

export const PLAN_ORDER = ["FREE", "STARTER", "GROWTH", "CUSTOM"];

/**
 * Minimal feature-gate stub. Nothing is actually restricted yet
 * (free-first, no imaginary limits) — this just gives future code a
 * single place to ask the question instead of scattering plan
 * checks everywhere once real limits exist.
 */
export function hasFeature(_planKey, _featureKey) {
  return true;
}

export function getPlan(planKey) {
  return PLANS[planKey] || PLANS.FREE;
}
