// SkillBridge — profile data access
// -----------------------------------------------------------------
// Every call here goes through the Supabase client authenticated
// with the current user's session and the PUBLISHABLE key. There is
// no service-role access anywhere in this file — Row Level Security
// on the `profiles` table (auth.uid() = id) is what actually
// prevents one user from reading or writing another user's row.
// -----------------------------------------------------------------

import { supabase } from "./supabase-client.js";

const PROFILE_FIELDS = [
  "full_name", "phone", "country", "city", "main_skill", "services",
  "portfolio_url", "experience", "target_industries", "target_countries",
  "preferred_market", "company", "avatar_url",
];

/** Fetch the current user's own profile row. RLS guarantees this can never return someone else's. */
export async function getMyProfile() {
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError || !user) return { data: null, error: userError || { message: "Not signed in." } };

  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .maybeSingle();

  return { data, error, user };
}

/**
 * Update the current user's profile. Only the allow-listed fields
 * below can ever be written — email and id are never accepted from
 * this form, so there's no path for a user to rewrite their own
 * identity fields through this function even by tampering with the
 * request payload client-side (RLS would block a different id anyway).
 */
export async function updateMyProfile(fields) {
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError || !user) return { data: null, error: userError || { message: "Not signed in." } };

  const payload = {};
  for (const key of PROFILE_FIELDS) {
    if (key in fields) payload[key] = fields[key]?.toString().trim() || null;
  }

  const { data, error } = await supabase
    .from("profiles")
    .update(payload)
    .eq("id", user.id)
    .select()
    .maybeSingle();

  return { data, error };
}
