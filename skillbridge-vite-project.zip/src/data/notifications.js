import { supabase } from "../supabase-client.js";

export async function listNotifications({ limit = 10 } = {}) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: [], error: { message: "Not signed in." } };
  const { data, error } = await supabase.from("notifications").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(limit);
  return { data: data || [], error };
}
export async function getUnreadCount() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return 0;
  const { count } = await supabase.from("notifications").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("is_read", false);
  return count || 0;
}
export async function markNotificationRead(id) {
  const { error } = await supabase.from("notifications").update({ is_read: true }).eq("id", id);
  return { error };
}
export async function markAllNotificationsRead() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: { message: "Not signed in." } };
  const { error } = await supabase.from("notifications").update({ is_read: true }).eq("user_id", user.id).eq("is_read", false);
  return { error };
}
const TYPE_ICONS = { new_opportunities: "🔥", report_ready: "📄", new_offer: "🎁", reply_received: "📩", follow_up_due: "⏰", campaign_updated: "📊", daily_delivery: "🔥", automation_error: "⚠️" };
export function iconForType(type) { return TYPE_ICONS[type] || "🔔"; }
