// SkillBridge — admin check
// -----------------------------------------------------------------
// This is a UI convenience only (whether to show the Admin nav link
// / render the admin page's contents). It is NOT what actually
// protects the opportunities table — the RLS policies in
// 20260912122842_opportunities_campaigns_outreach.sql (using
// public.is_admin()) are the real enforcement, evaluated by
// Postgres on every request regardless of what the client does or
// sends. Even if someone bypassed this check entirely, writes to
// `opportunities` would still be rejected by the database for a
// non-admin user.
// -----------------------------------------------------------------

import { supabase } from "../supabase-client.js";

let cachedResult = null;

export async function isAdmin() {
  if (cachedResult !== null) return cachedResult;

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    cachedResult = false;
    return false;
  }

  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", user.id)
    .eq("role", "admin")
    .maybeSingle();

  cachedResult = !error && !!data;
  return cachedResult;
}

/** Call at the top of admin-only pages. Redirects non-admins to the dashboard. */
export async function requireAdmin() {
  const admin = await isAdmin();
  if (!admin) {
    window.location.replace("dashboard.html");
    return false;
  }
  return true;
}
