// SkillBridge — billing data access. Note there is NO function here
// to change a user's own plan — by design. The `subscriptions` table
// has no client-facing INSERT/UPDATE grant at all (see migration 3),
// so even if this file tried, Postgres would reject it.

import { supabase } from "../supabase-client.js";

export async function getMySubscription() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: { message: "Not signed in." } };

  const { data, error } = await supabase
    .from("subscriptions")
    .select("*")
    .eq("user_id", user.id)
    .maybeSingle();

  // Belt-and-suspenders client-side fallback: if a row genuinely
  // doesn't exist yet (e.g. trigger hasn't run / pre-migration user
  // the backfill missed), treat it as Free/Active rather than
  // erroring the whole billing page.
  if (!error && !data) {
    return { data: { plan: "FREE", status: "ACTIVE", started_at: null, expires_at: null, _implicit: true }, error: null };
  }
  return { data, error };
}

export async function getUsageCounts() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { opportunitiesSaved: 0, campaigns: 0, outreachContacts: 0 };

  const [{ count: saved }, { count: campaigns }, { count: outreach }] = await Promise.all([
    supabase.from("user_opportunities").select("id", { count: "exact", head: true }).eq("user_id", user.id),
    supabase.from("campaigns").select("id", { count: "exact", head: true }).eq("user_id", user.id),
    supabase.from("outreach_contacts").select("id", { count: "exact", head: true }).eq("user_id", user.id),
  ]);

  return {
    opportunitiesSaved: saved || 0,
    campaigns: campaigns || 0,
    outreachContacts: outreach || 0,
  };
}

/** Writes an audit log row. RLS guarantees this silently fails (returns an error) for non-admins. */
export async function logAdminAction(action, { targetType, targetId, metadata } = {}) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: { message: "Not signed in." } };
  const { error } = await supabase.from("admin_audit_logs").insert({
    admin_user_id: user.id,
    action,
    target_type: targetType || null,
    target_id: targetId || null,
    metadata: metadata || null,
  });
  return { error };
}
