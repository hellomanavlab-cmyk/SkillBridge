import { supabase } from "../supabase-client.js";
export const PAGE_SIZE = 15;
export async function listActiveOffers() {
  const { data, error } = await supabase.from("offers").select("*").order("created_at", { ascending: false });
  return { data: data || [], error };
}
export async function adminListOffers({ page = 1 } = {}) {
  const from = (page - 1) * PAGE_SIZE;
  const { data, error, count } = await supabase.from("offers").select("*", { count: "exact" }).order("created_at", { ascending: false }).range(from, from + PAGE_SIZE - 1);
  return { data: data || [], count: count || 0, error };
}
export async function adminCreateOffer(fields) {
  const { data, error } = await supabase.from("offers").insert(fields).select().maybeSingle();
  return { data, error };
}
export async function adminUpdateOffer(id, fields) {
  const { data, error } = await supabase.from("offers").update(fields).eq("id", id).select().maybeSingle();
  return { data, error };
}
export async function adminDeleteOffer(id) {
  const { error } = await supabase.from("offers").delete().eq("id", id);
  return { error };
}
