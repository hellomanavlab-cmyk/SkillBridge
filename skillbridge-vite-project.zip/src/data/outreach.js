// SkillBridge — Outreach Agent foundation. Nothing in this file (or
// anywhere in the project) sends an email, LinkedIn message, or
// WhatsApp message. It only prepares/tracks state in
// `outreach_contacts`, gated by RLS to the owning user.

import { supabase } from "../supabase-client.js";

export async function ensureOutreachContact(campaignId, opportunity) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: { message: "Not signed in." } };

  const { data, error } = await supabase
    .from("outreach_contacts")
    .upsert(
      {
        user_id: user.id,
        campaign_id: campaignId,
        opportunity_id: opportunity.id,
        company_name: opportunity.company_name,
      },
      { onConflict: "campaign_id,opportunity_id", ignoreDuplicates: true }
    )
    .select()
    .maybeSingle();

  return { data, error };
}

export async function listOutreachContacts(campaignId) {
  const { data, error } = await supabase
    .from("outreach_contacts")
    .select("*, opportunity:opportunities(*)")
    .eq("campaign_id", campaignId)
    .order("created_at", { ascending: false });
  return { data: data || [], error };
}

export async function setContactStatus(id, status) {
  const { data, error } = await supabase
    .from("outreach_contacts")
    .update({ status })
    .eq("id", id)
    .select()
    .maybeSingle();
  return { data, error };
}

/** Dashboard-style aggregate counts for the Outreach Agent overview. Real data only. */
export async function getOutreachCounts() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { totalCampaigns: 0, readyCampaigns: 0, contactsToReach: 0, followUpsDue: 0, replies: 0, interested: 0 };

  const [{ data: campaigns }, { data: contacts }] = await Promise.all([
    supabase.from("campaigns").select("id, status").eq("user_id", user.id),
    supabase.from("outreach_contacts").select("status").eq("user_id", user.id),
  ]);

  const totalCampaigns = campaigns?.length || 0;
  const readyCampaigns = (campaigns || []).filter((c) => c.status === "READY" || c.status === "ACTIVE").length;
  const contactsToReach = (contacts || []).filter((c) => c.status === "READY" || c.status === "QUEUED").length;
  const followUpsDue = (contacts || []).filter((c) => c.status === "FOLLOW_UP_DUE").length;
  const replies = (contacts || []).filter((c) => c.status === "REPLIED").length;
  const interested = (contacts || []).filter((c) => c.status === "INTERESTED").length;

  return { totalCampaigns, readyCampaigns, contactsToReach, followUpsDue, replies, interested };
}

// ---------------------------------------------------------------
// Follow-up schedule "settings" — preparation only, not wired to
// any sending system yet, so there's no dedicated table for it.
// Stored per-browser in localStorage until Step 10+ introduces
// actual automation and a real settings table becomes worth adding.
// ---------------------------------------------------------------
const SETTINGS_KEY = "skillbridge_outreach_settings";

export function getOutreachSettings() {
  try {
    return JSON.parse(localStorage.getItem(SETTINGS_KEY)) || defaultSettings();
  } catch {
    return defaultSettings();
  }
}

export function saveOutreachSettings(settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function defaultSettings() {
  return {
    primaryChannel: "EMAIL",
    schedule: { initial: 0, followUp1: 3, followUp2: 7, followUp3: 14 },
  };
}
