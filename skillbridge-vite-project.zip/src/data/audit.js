// SkillBridge — admin audit log reads. There's no direct foreign
// key from admin_audit_logs to profiles (both just reference
// auth.users independently), so PostgREST can't embed the join —
// we fetch logs, then fetch the admin names/emails separately and
// merge client-side.

import { supabase } from "../supabase-client.js";

export const PAGE_SIZE = 20;

export async function listAuditLogs({ page = 1, action = "" } = {}) {
  let query = supabase
    .from("admin_audit_logs")
    .select("*", { count: "exact" })
    .order("created_at", { ascending: false });

  if (action) query = query.eq("action", action);

  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;
  const { data, error, count } = await query.range(from, to);
  if (error || !data) return { data: [], count: 0, error };

  const adminIds = [...new Set(data.map((r) => r.admin_user_id))];
  const { data: admins } = adminIds.length
    ? await supabase.from("profiles").select("id, full_name, email").in("id", adminIds)
    : { data: [] };

  const merged = data.map((row) => ({
    ...row,
    admin: admins?.find((a) => a.id === row.admin_user_id) || null,
  }));

  return { data: merged, count: count || 0, error: null };
}
