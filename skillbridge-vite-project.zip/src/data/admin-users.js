// SkillBridge — admin user management. Relies on the "Admins can
// view any profile" / "Admins can view all subscriptions" RLS
// policies — a non-admin calling these functions would simply get
// their own row back (or nothing), never another user's data.

import { supabase } from "../supabase-client.js";

export const PAGE_SIZE = 15;

export async function listUsers({ search = "", plan = "", status = "", page = 1 } = {}) {
  let query = supabase
    .from("profiles")
    .select("id, full_name, email, country, city, main_skill, account_status, created_at", { count: "exact" })
    .order("created_at", { ascending: false });

  if (search.trim()) {
    const term = `%${search.trim()}%`;
    query = query.or(`full_name.ilike.${term},email.ilike.${term}`);
  }
  if (status) query = query.eq("account_status", status);

  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;
  const { data: profiles, error, count } = await query.range(from, to);
  if (error || !profiles) return { data: [], count: 0, error };

  const ids = profiles.map((p) => p.id);
  const { data: subs } = ids.length
    ? await supabase.from("subscriptions").select("user_id, plan, status").in("user_id", ids)
    : { data: [] };

  let merged = profiles.map((p) => ({
    ...p,
    plan: subs?.find((s) => s.user_id === p.id)?.plan || "FREE",
    subStatus: subs?.find((s) => s.user_id === p.id)?.status || "ACTIVE",
  }));

  if (plan) merged = merged.filter((u) => u.plan === plan);

  return { data: merged, count: count || 0, error: null };
}

export async function getUserDetail(userId) {
  const [{ data: profile }, { data: subscription }, { count: oppCount }, { count: campaignCount }] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
    supabase.from("subscriptions").select("*").eq("user_id", userId).maybeSingle(),
    supabase.from("user_opportunities").select("id", { count: "exact", head: true }).eq("user_id", userId),
    supabase.from("campaigns").select("id", { count: "exact", head: true }).eq("user_id", userId),
  ]);

  return { profile, subscription, oppCount: oppCount || 0, campaignCount: campaignCount || 0 };
}

export async function setUserAccountStatus(userId, status) {
  const { data, error } = await supabase
    .from("profiles")
    .update({ account_status: status })
    .eq("id", userId)
    .select()
    .maybeSingle();
  return { data, error };
}
