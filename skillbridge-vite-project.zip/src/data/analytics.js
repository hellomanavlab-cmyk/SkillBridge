// SkillBridge — analytics & reports data access. Every number here
// comes from an actual query scoped to the current user (RLS also
// backs this up independently). No chart or metric is fabricated;
// where there's no data, callers show an empty state instead.

import { supabase } from "../supabase-client.js";

export const RANGE_OPTIONS = [
  { key: "7d", label: "Last 7 days", days: 7 },
  { key: "30d", label: "Last 30 days", days: 30 },
  { key: "90d", label: "Last 90 days", days: 90 },
  { key: "all", label: "All time", days: null },
];

export function rangeToDate(rangeKey) {
  const opt = RANGE_OPTIONS.find((r) => r.key === rangeKey) || RANGE_OPTIONS[3];
  if (!opt.days) return null;
  const d = new Date();
  d.setDate(d.getDate() - opt.days);
  return d.toISOString();
}

const USER_OPP_STATUSES = ["NEW", "SAVED", "CONTACTED", "FOLLOW_UP", "REPLIED", "INTERESTED", "MEETING", "WON", "LOST", "NOT_INTERESTED"];

/**
 * Core pipeline breakdown for the current user, optionally scoped to
 * a since-date (applied to user_opportunities.saved_at).
 */
export async function getOpportunityAnalytics(sinceIso = null) {
  const { data: { user } } = await supabase.auth.getUser();
  const empty = { total: 0, byStatus: Object.fromEntries(USER_OPP_STATUSES.map((s) => [s, 0])), relCount: 0 };
  if (!user) return empty;

  const { count: total } = await supabase
    .from("opportunities")
    .select("id", { count: "exact", head: true })
    .eq("status", "ACTIVE");

  let relQuery = supabase.from("user_opportunities").select("status").eq("user_id", user.id);
  if (sinceIso) relQuery = relQuery.gte("saved_at", sinceIso);
  const { data: relations } = await relQuery;

  const byStatus = Object.fromEntries(USER_OPP_STATUSES.map((s) => [s, (relations || []).filter((r) => r.status === s).length]));

  return { total: total || 0, byStatus, relCount: relations?.length || 0 };
}

/** Per-campaign rollup: opportunity count + outreach-contact status breakdown + won/lost from the user's own pipeline. */
export async function getCampaignAnalytics() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  const { data: campaigns } = await supabase
    .from("campaigns")
    .select("id, name, channel, status, campaign_opportunities(count)")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  if (!campaigns?.length) return [];

  const campaignIds = campaigns.map((c) => c.id);

  const [{ data: contacts }, { data: links }, { data: relations }] = await Promise.all([
    supabase.from("outreach_contacts").select("campaign_id, status").eq("user_id", user.id),
    supabase.from("campaign_opportunities").select("campaign_id, opportunity_id").in("campaign_id", campaignIds),
    supabase.from("user_opportunities").select("opportunity_id, status").eq("user_id", user.id),
  ]);

  return campaigns.map((c) => {
    const rows = (contacts || []).filter((r) => r.campaign_id === c.id);
    const countBy = (s) => rows.filter((r) => r.status === s).length;

    // Won/Lost live on the user's pipeline (user_opportunities), not
    // outreach_contacts — join campaign -> its opportunities -> the
    // user's own status for each, since that's where WON/LOST is set.
    const oppIdsInCampaign = (links || []).filter((l) => l.campaign_id === c.id).map((l) => l.opportunity_id);
    const relForCampaign = (relations || []).filter((r) => oppIdsInCampaign.includes(r.opportunity_id));

    return {
      id: c.id,
      name: c.name,
      channel: c.channel,
      status: c.status,
      totalOpportunities: c.campaign_opportunities?.[0]?.count ?? 0,
      ready: countBy("READY"),
      contacted: countBy("SENT") + countBy("QUEUED"),
      replies: countBy("REPLIED"),
      interested: countBy("INTERESTED"),
      meetings: countBy("MEETING_REQUEST"),
      won: relForCampaign.filter((r) => r.status === "WON").length,
      lost: relForCampaign.filter((r) => r.status === "LOST").length,
    };
  });
}

/** Channel-level rollup across all of the user's outreach contacts. */
export async function getChannelAnalytics() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { hasActivity: false, rows: [] };

  const { data: campaigns } = await supabase.from("campaigns").select("id, channel").eq("user_id", user.id);
  const { data: contacts } = await supabase.from("outreach_contacts").select("campaign_id, status").eq("user_id", user.id);

  if (!contacts?.length) return { hasActivity: false, rows: [] };

  const channelOf = (campaignId) => campaigns?.find((c) => c.id === campaignId)?.channel || "EMAIL";
  const channels = ["EMAIL", "LINKEDIN", "WHATSAPP", "MULTI_CHANNEL"];

  const rows = channels.map((ch) => {
    const rowsForChannel = contacts.filter((c) => channelOf(c.campaign_id) === ch);
    return {
      channel: ch,
      contacts: rowsForChannel.length,
      sent: rowsForChannel.filter((r) => ["SENT", "FOLLOW_UP_DUE", "REPLIED", "INTERESTED", "NOT_INTERESTED"].includes(r.status)).length,
      replies: rowsForChannel.filter((r) => r.status === "REPLIED").length,
      interested: rowsForChannel.filter((r) => r.status === "INTERESTED").length,
      meetings: rowsForChannel.filter((r) => r.status === "MEETING_REQUEST").length,
    };
  }).filter((r) => r.contacts > 0);

  return { hasActivity: rows.length > 0, rows };
}

/** Simple time-series source: raw rows for the selected range, aggregated by the caller per day. */
export async function getTrend(sinceIso) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  let query = supabase.from("user_opportunities").select("status, saved_at, updated_at").eq("user_id", user.id);
  if (sinceIso) query = query.gte("saved_at", sinceIso);
  const { data } = await query;
  return data || [];
}
