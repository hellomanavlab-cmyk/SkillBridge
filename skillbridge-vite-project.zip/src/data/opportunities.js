// SkillBridge — opportunities data access. Every query runs under
// the current user's session; RLS on `opportunities` and
// `user_opportunities` (see migration 2) is what actually enforces
// who can see and touch what — this file just shapes the calls.

import { supabase } from "../supabase-client.js";

export const PAGE_SIZE = 12;

/**
 * List opportunities visible to the current user (RLS already limits
 * this to status='ACTIVE' unless the caller is an admin), with
 * optional filters, sort, and pagination. Also left-joins the
 * caller's own user_opportunities row (if any) so cards can show
 * "Saved" state without a second round trip per card.
 */
export async function listOpportunities({
  search = "", industry = "", country = "", city = "",
  minScore = null, sort = "newest", page = 1,
} = {}) {
  const { data: { user } } = await supabase.auth.getUser();

  let query = supabase
    .from("opportunities")
    .select("*", { count: "exact" })
    .eq("status", "ACTIVE");

  if (search.trim()) {
    const term = `%${search.trim()}%`;
    query = query.or(`company_name.ilike.${term},title.ilike.${term},industry.ilike.${term}`);
  }
  if (industry) query = query.eq("industry", industry);
  if (country) query = query.eq("country", country);
  if (city) query = query.eq("city", city);
  if (minScore !== null && minScore !== "") query = query.gte("opportunity_score", Number(minScore));

  if (sort === "score") query = query.order("opportunity_score", { ascending: false, nullsFirst: false });
  else query = query.order("created_at", { ascending: false });

  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;
  query = query.range(from, to);

  const { data, error, count } = await query;
  if (error || !user) return { data: data || [], count: count || 0, error, savedMap: {} };

  // Fetch the current user's saved-state for just the opportunities on this page.
  const ids = (data || []).map((o) => o.id);
  let savedMap = {};
  if (ids.length) {
    const { data: userOpps } = await supabase
      .from("user_opportunities")
      .select("opportunity_id, status")
      .eq("user_id", user.id)
      .in("opportunity_id", ids);
    (userOpps || []).forEach((row) => { savedMap[row.opportunity_id] = row.status; });
  }

  return { data: data || [], count: count || 0, error: null, savedMap };
}

export async function getFilterOptions() {
  const { data, error } = await supabase
    .from("opportunities")
    .select("industry, country, city")
    .eq("status", "ACTIVE")
    .limit(1000);
  if (error || !data) return { industries: [], countries: [], cities: [] };
  const uniq = (key) => [...new Set(data.map((r) => r[key]).filter(Boolean))].sort();
  return { industries: uniq("industry"), countries: uniq("country"), cities: uniq("city") };
}

export async function getOpportunity(id) {
  const { data, error } = await supabase.from("opportunities").select("*").eq("id", id).maybeSingle();
  return { data, error };
}

export async function getMyRelationship(opportunityId) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: { message: "Not signed in." } };
  const { data, error } = await supabase
    .from("user_opportunities")
    .select("*")
    .eq("user_id", user.id)
    .eq("opportunity_id", opportunityId)
    .maybeSingle();
  return { data, error };
}

/** Save an opportunity (creates the user_opportunities row if it doesn't exist yet). */
export async function saveOpportunity(opportunityId) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: { message: "Not signed in." } };
  const { data, error } = await supabase
    .from("user_opportunities")
    .upsert({ user_id: user.id, opportunity_id: opportunityId, status: "SAVED" }, { onConflict: "user_id,opportunity_id" })
    .select()
    .maybeSingle();
  return { data, error };
}

export async function removeSavedOpportunity(opportunityId) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: { message: "Not signed in." } };
  const { error } = await supabase
    .from("user_opportunities")
    .delete()
    .eq("user_id", user.id)
    .eq("opportunity_id", opportunityId);
  return { error };
}

export async function updateRelationship(opportunityId, { status, notes }) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: { message: "Not signed in." } };
  const payload = {};
  if (status !== undefined) payload.status = status;
  if (notes !== undefined) payload.notes = notes;
  const { data, error } = await supabase
    .from("user_opportunities")
    .update(payload)
    .eq("user_id", user.id)
    .eq("opportunity_id", opportunityId)
    .select()
    .maybeSingle();
  return { data, error };
}

/** List the current user's saved opportunities, joined with the opportunity details. */
export async function listSavedOpportunities({ page = 1 } = {}) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: [], count: 0, error: { message: "Not signed in." } };

  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;

  const { data, error, count } = await supabase
    .from("user_opportunities")
    .select("*, opportunity:opportunities(*)", { count: "exact" })
    .eq("user_id", user.id)
    .order("saved_at", { ascending: false })
    .range(from, to);

  return { data: data || [], count: count || 0, error };
}

// ---------------------------------------------------------------
// Admin-only writes. RLS (public.is_admin()) rejects these for any
// non-admin regardless of what the client sends.
// ---------------------------------------------------------------
export async function adminListOpportunities({ page = 1, search = "", reviewStatus = "" } = {}) {
  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;
  let query = supabase.from("opportunities").select("*", { count: "exact" }).order("created_at", { ascending: false });
  if (search.trim()) query = query.ilike("company_name", `%${search.trim()}%`);
  if (reviewStatus) query = query.eq("review_status", reviewStatus);
  const { data, error, count } = await query.range(from, to);
  return { data: data || [], count: count || 0, error };
}

export async function adminCreateOpportunity(fields) {
  const { data, error } = await supabase.from("opportunities").insert(fields).select().maybeSingle();
  return { data, error };
}

export async function adminUpdateOpportunity(id, fields) {
  const { data, error } = await supabase.from("opportunities").update(fields).eq("id", id).select().maybeSingle();
  return { data, error };
}

export async function adminDeleteOpportunity(id) {
  const { error } = await supabase.from("opportunities").delete().eq("id", id);
  return { error };
}
