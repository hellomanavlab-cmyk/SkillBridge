// SkillBridge — dashboard statistics. Every number here comes from
// an actual COUNT query. If a table is empty, the number is 0 —
// there is no fallback/placeholder data anywhere in this file.

import { supabase } from "../supabase-client.js";

export async function getOpportunityStats() {
  const { data: { user } } = await supabase.auth.getUser();
  const zero = { total: 0, newCount: 0, contacted: 0, followUpsDue: 0, replies: 0, interested: 0 };
  if (!user) return zero;

  const { count: total } = await supabase
    .from("opportunities")
    .select("id", { count: "exact", head: true })
    .eq("status", "ACTIVE");

  const { data: relations } = await supabase
    .from("user_opportunities")
    .select("opportunity_id, status")
    .eq("user_id", user.id);

  const relCount = relations?.length || 0;
  const byStatus = (s) => (relations || []).filter((r) => r.status === s).length;

  return {
    total: total || 0,
    newCount: Math.max((total || 0) - relCount, 0),
    contacted: byStatus("CONTACTED"),
    followUpsDue: byStatus("FOLLOW_UP"),
    replies: byStatus("REPLIED"),
    interested: byStatus("INTERESTED"),
  };
}

const PROFILE_COMPLETION_FIELDS = [
  "full_name", "phone", "country", "city", "main_skill", "services",
  "portfolio_url", "experience", "target_industries", "target_countries", "preferred_market",
];

export function computeProfileCompletion(profile) {
  if (!profile) return 0;
  const filled = PROFILE_COMPLETION_FIELDS.filter((f) => profile[f] && profile[f].toString().trim().length > 0).length;
  return Math.round((filled / PROFILE_COMPLETION_FIELDS.length) * 100);
}
