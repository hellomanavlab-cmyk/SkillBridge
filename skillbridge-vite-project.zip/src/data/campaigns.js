// SkillBridge — campaigns data access. RLS on `campaigns` and
// `campaign_opportunities` (migration 2) enforces ownership; this
// file never sends a user_id the client made up — it's always read
// from the authenticated session server-round-trip.

import { supabase } from "../supabase-client.js";

export const PAGE_SIZE = 10;

const VALID_TRANSITIONS = {
  DRAFT: ["READY", "ARCHIVED"],
  READY: ["ACTIVE", "DRAFT", "ARCHIVED"],
  ACTIVE: ["PAUSED", "COMPLETED", "ARCHIVED"],
  PAUSED: ["ACTIVE", "ARCHIVED"],
  COMPLETED: ["ARCHIVED"],
  ARCHIVED: [],
};

export function canTransition(from, to) {
  return (VALID_TRANSITIONS[from] || []).includes(to);
}

export async function listCampaigns({ search = "", status = "", channel = "", page = 1 } = {}) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: [], count: 0, error: { message: "Not signed in." } };

  let query = supabase
    .from("campaigns")
    .select("*, campaign_opportunities(count)", { count: "exact" })
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  if (search.trim()) query = query.ilike("name", `%${search.trim()}%`);
  if (status) query = query.eq("status", status);
  if (channel) query = query.eq("channel", channel);

  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;
  const { data, error, count } = await query.range(from, to);
  return { data: data || [], count: count || 0, error };
}

export async function getCampaign(id) {
  const { data, error } = await supabase.from("campaigns").select("*").eq("id", id).maybeSingle();
  return { data, error };
}

export async function createCampaign({ name, description, channel, opportunityIds = [] }) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: null, error: { message: "Not signed in." } };

  const { data: campaign, error } = await supabase
    .from("campaigns")
    .insert({ user_id: user.id, name: name.trim(), description: description?.trim() || null, channel })
    .select()
    .maybeSingle();

  if (error || !campaign) return { data: null, error };

  if (opportunityIds.length) {
    const rows = opportunityIds.map((opportunity_id) => ({ campaign_id: campaign.id, opportunity_id }));
    const { error: linkError } = await supabase.from("campaign_opportunities").insert(rows);
    if (linkError) return { data: campaign, error: linkError };
  }

  return { data: campaign, error: null };
}

export async function updateCampaign(id, fields) {
  const { data, error } = await supabase.from("campaigns").update(fields).eq("id", id).select().maybeSingle();
  return { data, error };
}

export async function deleteCampaign(id) {
  const { error } = await supabase.from("campaigns").delete().eq("id", id);
  return { error };
}

export async function setCampaignStatus(id, currentStatus, nextStatus) {
  if (!canTransition(currentStatus, nextStatus)) {
    return { data: null, error: { message: `Cannot move a campaign from ${currentStatus} to ${nextStatus}.` } };
  }
  if (nextStatus === "ACTIVE") {
    const { count } = await supabase
      .from("campaign_opportunities")
      .select("id", { count: "exact", head: true })
      .eq("campaign_id", id);
    if (!count) {
      return { data: null, error: { message: "Add at least one opportunity before activating this campaign." } };
    }
  }
  return updateCampaign(id, { status: nextStatus });
}

export async function listCampaignOpportunities(campaignId) {
  const { data, error } = await supabase
    .from("campaign_opportunities")
    .select("id, created_at, opportunity:opportunities(*)")
    .eq("campaign_id", campaignId)
    .order("created_at", { ascending: false });
  return { data: data || [], error };
}

export async function addOpportunitiesToCampaign(campaignId, opportunityIds) {
  const rows = opportunityIds.map((opportunity_id) => ({ campaign_id: campaignId, opportunity_id }));
  const { error } = await supabase.from("campaign_opportunities").insert(rows);
  return { error };
}

export async function removeOpportunityFromCampaign(campaignId, opportunityId) {
  const { error } = await supabase
    .from("campaign_opportunities")
    .delete()
    .eq("campaign_id", campaignId)
    .eq("opportunity_id", opportunityId);
  return { error };
}

/** Aggregate counts for the dashboard — real numbers only, "0" when empty. */
export async function getCampaignCounts() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { total: 0, active: 0, draft: 0, completed: 0 };

  const { data, error } = await supabase.from("campaigns").select("status").eq("user_id", user.id);
  if (error || !data) return { total: 0, active: 0, draft: 0, completed: 0 };

  return {
    total: data.length,
    active: data.filter((c) => c.status === "ACTIVE").length,
    draft: data.filter((c) => c.status === "DRAFT").length,
    completed: data.filter((c) => c.status === "COMPLETED").length,
  };
}
