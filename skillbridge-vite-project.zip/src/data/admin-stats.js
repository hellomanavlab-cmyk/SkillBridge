import { supabase } from "../supabase-client.js";

export async function getPlatformStats() {
  const [
    { count: totalUsers },
    { count: activeUsers },
    { count: totalOpportunities },
    { count: savedOpportunities },
    { count: totalCampaigns },
    { count: activeCampaigns },
    { count: outreachContacts },
    { count: interestedOpportunities },
  ] = await Promise.all([
    supabase.from("profiles").select("id", { count: "exact", head: true }),
    supabase.from("profiles").select("id", { count: "exact", head: true }).eq("account_status", "ACTIVE"),
    supabase.from("opportunities").select("id", { count: "exact", head: true }),
    supabase.from("user_opportunities").select("id", { count: "exact", head: true }),
    supabase.from("campaigns").select("id", { count: "exact", head: true }),
    supabase.from("campaigns").select("id", { count: "exact", head: true }).eq("status", "ACTIVE"),
    supabase.from("outreach_contacts").select("id", { count: "exact", head: true }),
    supabase.from("user_opportunities").select("id", { count: "exact", head: true }).eq("status", "INTERESTED"),
  ]);

  return {
    totalUsers: totalUsers || 0,
    activeUsers: activeUsers || 0,
    totalOpportunities: totalOpportunities || 0,
    savedOpportunities: savedOpportunities || 0,
    totalCampaigns: totalCampaigns || 0,
    activeCampaigns: activeCampaigns || 0,
    outreachContacts: outreachContacts || 0,
    interestedOpportunities: interestedOpportunities || 0,
  };
}

export async function getPlanDistribution() {
  const { data } = await supabase.from("subscriptions").select("plan");
  const counts = { FREE: 0, STARTER: 0, GROWTH: 0, CUSTOM: 0 };
  (data || []).forEach((row) => { if (counts[row.plan] !== undefined) counts[row.plan]++; });
  return counts;
}

/** Simple per-day counts for "new users over time" style trends. Real timestamps only. */
export async function getSignupTrend(sinceIso) {
  let query = supabase.from("profiles").select("created_at");
  if (sinceIso) query = query.gte("created_at", sinceIso);
  const { data } = await query;
  return data || [];
}
