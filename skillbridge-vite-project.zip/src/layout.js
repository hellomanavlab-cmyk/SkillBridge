// SkillBridge — shared app shell (sidebar + topbar) used by every
// authenticated page: dashboard, opportunities, campaigns, outreach.
// One implementation, so nav structure and behavior stay consistent
// instead of being copy-pasted across 8 HTML files.

import { logOutUser } from "./auth.js";
import { isAdmin } from "./data/admin.js";

const NAV_ITEMS = [
  { key: "overview", label: "Overview", href: "/dashboard.html", icon: "grid" },
  { key: "opportunities", label: "Opportunities", href: "/opportunities.html", icon: "target" },
  { key: "campaigns", label: "Campaigns", href: "/campaigns.html", icon: "megaphone" },
  { key: "outreach", label: "Outreach Agent", href: "/outreach.html", icon: "send" },
  { key: "analytics", label: "Analytics", href: "/analytics.html", icon: "chart" },
  { key: "reports", label: "Reports", href: "/reports.html", icon: "doc" },
  { key: "billing", label: "Billing", href: "/billing.html", icon: "card" },
  { key: "profile", label: "Profile", href: "/profile.html", icon: "user" },
  { key: "settings", label: "Settings", href: null, icon: "settings", soon: true },
];

const ICONS = {
  grid: '<svg viewBox="0 0 20 20" fill="none"><rect x="2.5" y="2.5" width="6" height="6" rx="1.5" stroke="currentColor" stroke-width="1.5"/><rect x="11.5" y="2.5" width="6" height="6" rx="1.5" stroke="currentColor" stroke-width="1.5"/><rect x="2.5" y="11.5" width="6" height="6" rx="1.5" stroke="currentColor" stroke-width="1.5"/><rect x="11.5" y="11.5" width="6" height="6" rx="1.5" stroke="currentColor" stroke-width="1.5"/></svg>',
  target: '<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><circle cx="10" cy="10" r="3.2" stroke="currentColor" stroke-width="1.5"/></svg>',
  megaphone: '<svg viewBox="0 0 20 20" fill="none"><path d="M3 8.5V11.5L6 12.5V15.5C6 16.3 6.7 17 7.5 17C8.3 17 9 16.3 9 15.5V13L15 15V5L9 7L3 8.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M15 5C16.5 6 17.3 8 17.3 10C17.3 12 16.5 14 15 15" stroke="currentColor" stroke-width="1.4"/></svg>',
  send: '<svg viewBox="0 0 20 20" fill="none"><path d="M17.5 2.5L2.5 8.5L9 11L11.5 17.5L17.5 2.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M17.5 2.5L9 11" stroke="currentColor" stroke-width="1.4"/></svg>',
  chart: '<svg viewBox="0 0 20 20" fill="none"><path d="M3 17V3M3 17H17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><rect x="6" y="10" width="2.4" height="5" fill="currentColor"/><rect x="10.5" y="7" width="2.4" height="8" fill="currentColor"/><rect x="15" y="4" width="2" height="11" fill="currentColor"/></svg>',
  doc: '<svg viewBox="0 0 20 20" fill="none"><path d="M5 2.5H12L15.5 6V17.5H5V2.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M7.5 10H12.5M7.5 13H12.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>',
  card: '<svg viewBox="0 0 20 20" fill="none"><rect x="2.5" y="5" width="15" height="10" rx="1.5" stroke="currentColor" stroke-width="1.4"/><path d="M2.5 8.5H17.5" stroke="currentColor" stroke-width="1.4"/></svg>',
  user: '<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="6.8" r="3.3" stroke="currentColor" stroke-width="1.4"/><path d="M3.5 17C4.3 13.7 6.9 12 10 12C13.1 12 15.7 13.7 16.5 17" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
  settings: '<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="2.6" stroke="currentColor" stroke-width="1.4"/><path d="M10 2.5V4.3M10 15.7V17.5M17.5 10H15.7M4.3 10H2.5M15.1 4.9L13.8 6.2M6.2 13.8L4.9 15.1M15.1 15.1L13.8 13.8M6.2 6.2L4.9 4.9" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
  admin: '<svg viewBox="0 0 20 20" fill="none"><path d="M10 2.5L16.5 5V9.5C16.5 13.5 13.7 16.7 10 17.5C6.3 16.7 3.5 13.5 3.5 9.5V5L10 2.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>',
  logout: '<svg viewBox="0 0 20 20" fill="none"><path d="M8 17.5H4.5C3.9 17.5 3.5 17.1 3.5 16.5V3.5C3.5 2.9 3.9 2.5 4.5 2.5H8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M13 14L17 10L13 6M17 10H7.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
};

function initials(name) {
  if (!name) return "?";
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] || "") + (parts[1]?.[0] || "")).toUpperCase() || name[0].toUpperCase();
}

/**
 * Renders the sidebar + topbar shell and moves any existing
 * #page-content element into the content area. Call once per page.
 * @param {{activeKey: string, pageTitle: string, user: object, displayName: string}} opts
 */
export async function mountAppShell({ activeKey, pageTitle, user, displayName }) {
  const admin = await isAdmin();

  const navHtml = NAV_ITEMS.map((item) => {
    const iconSvg = `<span class="nav-ico">${ICONS[item.icon]}</span>`;
    if (item.soon || !item.href) {
      return `<div class="nav-soon">${iconSvg}${item.label}<span class="soon-tag">Soon</span></div>`;
    }
    const activeClass = item.key === activeKey ? " active" : "";
    return `<a href="${item.href}" class="${activeClass.trim()}">${iconSvg}${item.label}</a>`;
  }).join("");

  const adminLink = admin
    ? `<a href="/admin-opportunities.html" class="${activeKey === "admin" ? "active" : ""}"><span class="nav-ico">${ICONS.admin}</span>Admin</a>`
    : "";

  const shellHtml = `
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <aside class="app-sidebar" id="appSidebar">
      <a href="/index.html" class="brand"><span class="skill">Skill</span><span class="bridge">Bridge</span></a>
      <nav class="app-nav">
        ${navHtml}
        ${adminLink ? `<div class="group-label">Admin</div>${adminLink}` : ""}
      </nav>
      <div class="sidebar-foot">
        <button class="logout-link nav-soon" id="sidebarLogout" style="opacity:1; color:#b3452b; cursor:pointer">
          <span class="nav-ico">${ICONS.logout}</span>Logout
        </button>
      </div>
    </aside>

    <div class="app-main">
      <header class="app-topbar">
        <div style="display:flex; align-items:center; gap:14px">
          <button class="icon-btn burger-btn" id="burgerBtn" aria-label="Open menu">
            <svg width="18" height="18" viewBox="0 0 20 20" fill="none"><path d="M3 5H17M3 10H17M3 15H17" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
          </button>
          <span class="page-title">${pageTitle}</span>
        </div>
        <div class="topbar-search">
          <svg width="14" height="14" viewBox="0 0 20 20" fill="none"><circle cx="9" cy="9" r="6" stroke="currentColor" stroke-width="1.5"/><path d="M17 17L13.5 13.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
          Search (coming soon)
        </div>
        <div class="topbar-right">
          <button class="icon-btn" aria-label="Notifications" title="Notifications — coming soon">
            <svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M5 8C5 5.2 7.2 3 10 3C12.8 3 15 5.2 15 8V11L16.5 14H3.5L5 11V8Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M8 16.5C8.3 17.3 9.1 17.8 10 17.8C10.9 17.8 11.7 17.3 12 16.5" stroke="currentColor" stroke-width="1.4"/></svg>
          </button>
          <div class="user-chip" id="userChip">
            <span class="avatar">${initials(displayName)}</span>
            <span class="u-name">${displayName}</span>
            <div class="user-menu" id="userMenu">
              <a href="/profile.html">Edit Profile</a>
              <a href="/billing.html">Billing &amp; Plans</a>
              <button id="menuLogout">Log Out</button>
            </div>
          </div>
        </div>
      </header>
      <div class="app-content" id="appContent"></div>
    </div>
  `;

  const existingContent = document.getElementById("page-content");
  const contentHtml = existingContent ? existingContent.innerHTML : "";

  document.body.classList.add("app-shell");
  document.body.innerHTML = shellHtml;
  document.getElementById("appContent").innerHTML = contentHtml;

  wireShellEvents();
}

function wireShellEvents() {
  const sidebar = document.getElementById("appSidebar");
  const overlay = document.getElementById("sidebarOverlay");
  const burger = document.getElementById("burgerBtn");
  burger?.addEventListener("click", () => {
    sidebar.classList.add("open");
    overlay.classList.add("show");
  });
  overlay?.addEventListener("click", () => {
    sidebar.classList.remove("open");
    overlay.classList.remove("show");
  });

  const userChip = document.getElementById("userChip");
  const userMenu = document.getElementById("userMenu");
  userChip?.addEventListener("click", (e) => {
    e.stopPropagation();
    userMenu.classList.toggle("open");
  });
  document.addEventListener("click", () => userMenu?.classList.remove("open"));

  const doLogout = async () => {
    await logOutUser();
    window.location.replace("/login.html");
  };
  document.getElementById("sidebarLogout")?.addEventListener("click", doLogout);
  document.getElementById("menuLogout")?.addEventListener("click", doLogout);
}
